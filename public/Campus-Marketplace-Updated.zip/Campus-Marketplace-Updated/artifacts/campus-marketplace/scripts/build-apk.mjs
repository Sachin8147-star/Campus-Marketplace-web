// Builds the web app and syncs it into the Android project.
// Push notifications are switched on only when Firebase is set up (android/app/google-services.json).
// Registering for push WITHOUT Firebase makes Android close the app, so it must stay off until then.
import { existsSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const googleServices = 'android/app/google-services.json';
const hasFirebase = existsSync(googleServices) && readFileSync(googleServices, 'utf8').trim().length > 20;
console.log(hasFirebase
  ? '\nFirebase found: push notifications are ENABLED in this build.\n'
  : '\nNo google-services.json: push notifications are OFF in this build (in-app notifications still work).\n');

const run = (args) => {
  const result = spawnSync('pnpm', ['exec', ...args], { stdio: 'inherit', shell: true, env: { ...process.env, VITE_ENABLE_PUSH: hasFirebase ? 'true' : 'false' } });
  if (result.status !== 0) process.exit(result.status ?? 1);
};
run(['vite', 'build', '--config', 'vite.config.ts']);
run(['cap', 'sync', 'android']);
