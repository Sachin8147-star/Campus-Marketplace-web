import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.campus.marketplace',
  appName: 'Campus Marketplace',
  webDir: 'dist/public',
  server: {
    // Lets the app talk to a plain http:// backend (e.g. your laptop on Wi-Fi) while testing.
    // Use an https:// backend for the version you hand to other students.
    cleartext: true,
    allowNavigation: ['clerk.localhost', '*.clerk.accounts.dev', '*.clerk.com', '*.clerk.dev'],
  },
  android: {
    allowMixedContent: true,
  },
};

export default config;
