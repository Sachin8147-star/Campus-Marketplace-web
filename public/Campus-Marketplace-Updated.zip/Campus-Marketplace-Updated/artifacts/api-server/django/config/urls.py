from django.contrib import admin
from django.urls import path
from django.views.generic import RedirectView

from marketplace import auth_views, views

urlpatterns = [
    path("api/admin", RedirectView.as_view(url="/api/admin/")),
    path("api/admin/", admin.site.urls),
    path("api/healthz", views.health_check),

    # Google OAuth Routes
    path("api/auth/google", auth_views.google_oauth_start),
    path("api/auth/google/callback", auth_views.google_oauth_callback),
    path("api/auth/google/verify", auth_views.google_verify_id_token),

    # Marketplace Routes (Unchanged)
    path("api/listings", views.list_listings),
    path("api/listings/<int:listing_id>", views.listing_detail),
    path("api/me/listings", views.my_listings),
    path("api/dashboard", views.dashboard_summary),
    path("api/favorites", views.favorites),
    path("api/listings/<int:listing_id>/favorite", views.favorite_detail),
    path("api/listings/<int:listing_id>/inquiries", views.listing_inquiries),
    path("api/inquiries", views.inquiries),
    path("api/uploads", views.upload_listing_photo),
    path("api/diag", views.diagnostics),
    path("api/inbox/unread", views.inbox_unread),
    path("api/inbox/read", views.inbox_read),
    path("api/notifications", views.notifications),
    path("api/notifications/seen", views.notifications_seen),
    path("api/push/register", views.push_register),
    path("api/sellers/<str:seller_id>", views.seller_profile),
]
