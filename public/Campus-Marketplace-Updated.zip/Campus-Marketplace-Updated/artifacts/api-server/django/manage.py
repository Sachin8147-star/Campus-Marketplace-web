#!/usr/bin/env python3
import os
import sys


if __name__ == "__main__":
    # Attempt to load environment variables from the root .env file
    try:
        from pathlib import Path
        import os

        # Walk up from artifacts/api-server/django/manage.py to the root .env
        env_path = Path(__file__).resolve().parent.parent.parent.parent / ".env"
        if env_path.exists():
            with open(env_path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#"):
                        key, value = line.split("=", 1)
                        os.environ.setdefault(key.strip(), value.strip())
    except Exception:
        pass

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
