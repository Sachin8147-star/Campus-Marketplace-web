from django.contrib import admin
from django.utils.html import format_html

from .clerk_profiles import get_profiles
from .models import Favorite, Inquiry, Listing, Notification, PushToken, Report

admin.site.site_header = "campuscrate admin"
admin.site.site_title = "campuscrate admin"
admin.site.index_title = "Reports and marketplace data"


def _who(user_id: str) -> str:
    profile = get_profiles([user_id]).get(user_id) if user_id else None
    if profile:
        return f"{profile.get('name') or 'Student'} ({profile.get('email') or user_id})"
    return user_id or "Signed-out visitor"


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ("id", "created_at", "from_student", "short_message", "resolved")
    list_display_links = ("id", "short_message")
    list_editable = ("resolved",)
    list_filter = ("resolved", "created_at")
    search_fields = ("message", "contact", "user_id")
    ordering = ("-created_at",)
    date_hierarchy = "created_at"
    actions = ["mark_resolved", "mark_open"]
    fields = ("resolved", "from_student", "contact", "message", "created_at")
    readonly_fields = ("from_student", "contact", "message", "created_at")

    @admin.display(description="From")
    def from_student(self, obj: Report) -> str:
        return _who(obj.user_id)

    @admin.display(description="Message")
    def short_message(self, obj: Report) -> str:
        return format_html("{}", (obj.message[:90] + "…") if len(obj.message) > 90 else obj.message)

    @admin.action(description="Mark selected reports as resolved")
    def mark_resolved(self, request, queryset):
        self.message_user(request, f"{queryset.update(resolved=True)} report(s) marked resolved.")

    @admin.action(description="Mark selected reports as open")
    def mark_open(self, request, queryset):
        self.message_user(request, f"{queryset.update(resolved=False)} report(s) re-opened.")

    def has_add_permission(self, request):
        return False


@admin.register(Listing)
class ListingAdmin(admin.ModelAdmin):
    list_display = ("id", "title", "category", "listing_type", "price", "status", "seller_name", "created_at")
    list_filter = ("status", "listing_type", "category")
    search_fields = ("title", "description", "seller_name", "seller_id")
    ordering = ("-created_at",)


@admin.register(Inquiry)
class InquiryAdmin(admin.ModelAdmin):
    list_display = ("id", "listing", "sender_name", "created_at")
    search_fields = ("message", "sender_name", "sender_id")
    ordering = ("-created_at",)


@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display = ("id", "user_id", "listing", "created_at")


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("id", "kind", "title", "user_id", "created_at")
    list_filter = ("kind",)
    ordering = ("-created_at",)


@admin.register(PushToken)
class PushTokenAdmin(admin.ModelAdmin):
    list_display = ("id", "user_id", "created_at")
