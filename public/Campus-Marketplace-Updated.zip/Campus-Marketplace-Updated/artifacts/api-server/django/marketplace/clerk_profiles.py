import logging
import os
import time

import requests
from .models import StudentProfile

logger = logging.getLogger(__name__)

_CACHE: dict[str, tuple[float, dict | None]] = {}
_TTL_OK = 600
_TTL_FAIL = 60


def _profile_from_user(user: dict) -> dict:
    name = " ".join(part for part in [user.get("first_name"), user.get("last_name")] if part).strip()
    name = name or user.get("username") or ""
    primary_email = next(
        (e.get("email_address") for e in user.get("email_addresses", []) if e.get("id") == user.get("primary_email_address_id")),
        None,
    ) or next((e.get("email_address") for e in user.get("email_addresses", [])), None)
    primary_phone = next(
        (p.get("phone_number") for p in user.get("phone_numbers", []) if p.get("id") == user.get("primary_phone_number_id")),
        None,
    )
    metadata = user.get("unsafe_metadata") or {}
    return {
        "name": name,
        "imageUrl": user.get("image_url") if user.get("has_image") else None,
        "email": primary_email,
        "phone": metadata.get("phone") or primary_phone,
    }


def get_profiles(user_ids) -> dict[str, dict]:
    wanted = [uid for uid in dict.fromkeys(user_ids) if uid]
    if not wanted:
        return {}

    profiles: dict[str, dict] = {}

    # 1. Resolve direct Google profiles from local database
    google_uids = [u for u in wanted if u.startswith("google_")]
    if google_uids:
        try:
            for student in StudentProfile.objects.filter(user_id__in=google_uids):
                profiles[student.user_id] = {
                    "name": student.name,
                    "imageUrl": student.image_url,
                    "email": student.email,
                    "phone": student.phone,
                }
        except Exception:
            logger.warning("Could not query StudentProfile from database")

    # 2. Resolve Clerk profiles (kept intact for email login)
    clerk_uids = [uid for uid in wanted if uid.startswith("user_")]
    secret = os.environ.get("CLERK_SECRET_KEY")
    now = time.time()
    missing = [uid for uid in clerk_uids if uid not in _CACHE or now - _CACHE[uid][0] > (_TTL_OK if _CACHE[uid][1] else _TTL_FAIL)]
    if missing and secret:
        for start in range(0, len(missing), 100):
            chunk = missing[start : start + 100]
            try:
                response = requests.get(
                    "https://api.clerk.com/v1/users",
                    params=[("user_id", uid) for uid in chunk] + [("limit", len(chunk))],
                    headers={"Authorization": f"Bearer {secret}"},
                    timeout=6,
                )
                response.raise_for_status()
                found = {user["id"]: _profile_from_user(user) for user in response.json()}
            except (requests.RequestException, ValueError, KeyError):
                logger.warning("Could not load seller profiles from Clerk")
                found = {}
            for uid in chunk:
                _CACHE[uid] = (now, found.get(uid))

    for uid in clerk_uids:
        if uid in _CACHE and _CACHE[uid][1]:
            profiles[uid] = _CACHE[uid][1]

    return profiles
