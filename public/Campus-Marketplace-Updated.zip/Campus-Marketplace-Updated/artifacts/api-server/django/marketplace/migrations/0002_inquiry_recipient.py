from django.db import migrations, models


class Migration(migrations.Migration):
    """Adds Inquiry.recipient_id.

    The column is created with IF NOT EXISTS so this migration also succeeds on a
    database where the column was already added by hand.
    """

    dependencies = [
        ("marketplace", "0001_initial"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql=[
                        "ALTER TABLE marketplace_inquiry ADD COLUMN IF NOT EXISTS recipient_id varchar(255) NULL;",
                        "CREATE INDEX IF NOT EXISTS marketplace_inquiry_recipient_id_idx ON marketplace_inquiry (recipient_id);",
                    ],
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.AddField(
                    model_name="inquiry",
                    name="recipient_id",
                    field=models.CharField(blank=True, db_index=True, max_length=255, null=True),
                ),
            ],
        ),
    ]
