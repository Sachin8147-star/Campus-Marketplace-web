from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("marketplace", "0002_inquiry_recipient"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql="ALTER TABLE marketplace_listing ADD COLUMN IF NOT EXISTS meetup jsonb NOT NULL DEFAULT '{}'::jsonb;",
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.AddField(
                    model_name="listing",
                    name="meetup",
                    field=models.JSONField(blank=True, default=dict),
                ),
            ],
        ),
    ]
