from django.db import migrations, models
import django.utils.timezone


class Migration(migrations.Migration):
    dependencies = [
        ("marketplace", "0005_notifications"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql="ALTER TABLE notification_state ADD COLUMN IF NOT EXISTS joined_at timestamptz NOT NULL DEFAULT now();",
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.AddField(
                    model_name="notificationstate",
                    name="joined_at",
                    field=models.DateTimeField(default=django.utils.timezone.now),
                ),
            ],
        ),
    ]
