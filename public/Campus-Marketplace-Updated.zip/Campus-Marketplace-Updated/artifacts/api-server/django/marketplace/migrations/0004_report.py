from django.db import migrations, models


class Migration(migrations.Migration):
    """The reports table is also created by the API gateway, so every step is idempotent."""

    dependencies = [
        ("marketplace", "0003_listing_meetup"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql=[
                        "CREATE TABLE IF NOT EXISTS reports (id serial PRIMARY KEY, user_id text NOT NULL DEFAULT '', contact text, message text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());",
                        "ALTER TABLE reports ALTER COLUMN created_at TYPE timestamptz USING created_at AT TIME ZONE 'UTC';",
                        "ALTER TABLE reports ADD COLUMN IF NOT EXISTS resolved boolean NOT NULL DEFAULT false;",
                    ],
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.CreateModel(
                    name="Report",
                    fields=[
                        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                        ("user_id", models.CharField(blank=True, default="", max_length=255)),
                        ("contact", models.TextField(blank=True, null=True)),
                        ("message", models.TextField()),
                        ("created_at", models.DateTimeField(auto_now_add=True)),
                        ("resolved", models.BooleanField(default=False)),
                    ],
                    options={"db_table": "reports", "ordering": ["-created_at"]},
                ),
            ],
        ),
    ]
