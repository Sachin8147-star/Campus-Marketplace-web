from django.db import migrations, models


class Migration(migrations.Migration):
    """Unread tracking for messages, the notifications feed and push tokens (all idempotent)."""

    dependencies = [
        ("marketplace", "0004_report"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql=[
                        "ALTER TABLE marketplace_inquiry ADD COLUMN IF NOT EXISTS read_at timestamptz NULL;",
                        # Messages that already exist count as read, so nobody starts with a pile of red dots.
                        "UPDATE marketplace_inquiry SET read_at = created_at WHERE read_at IS NULL;",
                        "CREATE TABLE IF NOT EXISTS notifications (id bigserial PRIMARY KEY, user_id varchar(255) NOT NULL DEFAULT '', author_id varchar(255) NOT NULL DEFAULT '', kind varchar(20) NOT NULL DEFAULT 'message', title varchar(160) NOT NULL, body text NOT NULL DEFAULT '', link varchar(255) NOT NULL DEFAULT '/', created_at timestamptz NOT NULL DEFAULT now());",
                        "CREATE INDEX IF NOT EXISTS notifications_user_idx ON notifications (user_id, created_at DESC);",
                        "CREATE TABLE IF NOT EXISTS notification_state (user_id varchar(255) PRIMARY KEY, seen_at timestamptz NOT NULL);",
                        "CREATE TABLE IF NOT EXISTS push_tokens (id bigserial PRIMARY KEY, user_id varchar(255) NOT NULL, token varchar(500) NOT NULL UNIQUE, created_at timestamptz NOT NULL DEFAULT now());",
                        "CREATE INDEX IF NOT EXISTS push_tokens_user_idx ON push_tokens (user_id);",
                    ],
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.AddField(model_name="inquiry", name="read_at", field=models.DateTimeField(blank=True, null=True)),
                migrations.CreateModel(
                    name="Notification",
                    fields=[
                        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                        ("user_id", models.CharField(blank=True, default="", max_length=255)),
                        ("author_id", models.CharField(blank=True, default="", max_length=255)),
                        ("kind", models.CharField(default="message", max_length=20)),
                        ("title", models.CharField(max_length=160)),
                        ("body", models.TextField(blank=True, default="")),
                        ("link", models.CharField(default="/", max_length=255)),
                        ("created_at", models.DateTimeField(auto_now_add=True)),
                    ],
                    options={"db_table": "notifications", "ordering": ["-created_at"]},
                ),
                migrations.CreateModel(
                    name="NotificationState",
                    fields=[
                        ("user_id", models.CharField(max_length=255, primary_key=True, serialize=False)),
                        ("seen_at", models.DateTimeField()),
                    ],
                    options={"db_table": "notification_state"},
                ),
                migrations.CreateModel(
                    name="PushToken",
                    fields=[
                        ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                        ("user_id", models.CharField(db_index=True, max_length=255)),
                        ("token", models.CharField(max_length=500, unique=True)),
                        ("created_at", models.DateTimeField(auto_now_add=True)),
                    ],
                    options={"db_table": "push_tokens"},
                ),
            ],
        ),
    ]
