from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("marketplace", "0006_notification_joined"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[
                migrations.RunSQL(
                    sql="""
                    CREATE TABLE IF NOT EXISTS student_profiles (
                        user_id varchar(255) PRIMARY KEY,
                        email varchar(254) NOT NULL UNIQUE,
                        name varchar(255) NOT NULL DEFAULT '',
                        image_url varchar(1000) NULL,
                        phone varchar(40) NULL,
                        created_at timestamptz NOT NULL DEFAULT now(),
                        updated_at timestamptz NOT NULL DEFAULT now()
                    );
                    """,
                    reverse_sql=migrations.RunSQL.noop,
                ),
            ],
            state_operations=[
                migrations.CreateModel(
                    name="StudentProfile",
                    fields=[
                        ("user_id", models.CharField(max_length=255, primary_key=True, serialize=False)),
                        ("email", models.EmailField(max_length=254, unique=True)),
                        ("name", models.CharField(blank=True, default="", max_length=255)),
                        ("image_url", models.URLField(blank=True, max_length=1000, null=True)),
                        ("phone", models.CharField(blank=True, max_length=40, null=True)),
                        ("created_at", models.DateTimeField(auto_now_add=True)),
                        ("updated_at", models.DateTimeField(auto_now=True)),
                    ],
                    options={"db_table": "student_profiles"},
                ),
            ],
        ),
    ]
