import re

from rest_framework import serializers

_TIME = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def clean_phone(value: str) -> str:
    """10-15 digits, optional leading +; spaces, dashes and brackets are ignored."""
    compact = re.sub(r"[\s\-().]", "", value or "")
    digits = compact[1:] if compact.startswith("+") else compact
    if not digits.isdigit() or not 10 <= len(digits) <= 15:
        raise serializers.ValidationError("Phone number must have 10 to 15 digits.")
    return compact


class PhoneField(serializers.CharField):
    def to_internal_value(self, data):
        return clean_phone(super().to_internal_value(data))


class MeetupSerializer(serializers.Serializer):
    place = serializers.CharField(max_length=160, required=False, allow_blank=True)
    house = serializers.CharField(max_length=120, required=False, allow_blank=True)
    street = serializers.CharField(max_length=160, required=False, allow_blank=True)
    landmark = serializers.CharField(max_length=160, required=False, allow_blank=True)
    city = serializers.CharField(max_length=80, required=False, allow_blank=True)
    pincode = serializers.RegexField(r"^\d{6}$", required=False, allow_blank=True, error_messages={"invalid": "Pincode must be 6 digits."})
    photoUrl = serializers.URLField(max_length=1200, required=False, allow_blank=True)
    timeFrom = serializers.RegexField(_TIME, required=False, allow_blank=True, error_messages={"invalid": "Use a time like 17:30."})
    timeTo = serializers.RegexField(_TIME, required=False, allow_blank=True, error_messages={"invalid": "Use a time like 17:30."})

    def to_internal_value(self, data):
        value = super().to_internal_value(data)
        return {key: item for key, item in value.items() if item}


class ListingInputSerializer(serializers.Serializer):
    title = serializers.CharField(min_length=3, max_length=120)
    description = serializers.CharField(min_length=10, max_length=3000)
    category = serializers.CharField(max_length=80)
    listingType = serializers.ChoiceField(choices=["sale", "rent"])
    price = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=0)
    priceUnit = serializers.ChoiceField(choices=["one-time", "day", "week", "month"])
    condition = serializers.ChoiceField(choices=["new", "like-new", "good", "fair"])
    status = serializers.ChoiceField(
        choices=["available", "reserved", "sold", "rented"], required=False
    )
    location = serializers.CharField(max_length=160)
    # Seller name/e-mail/phone are taken from the seller's profile; these are only a fallback.
    sellerName = serializers.CharField(max_length=120, required=False, allow_blank=True)
    sellerPhone = PhoneField(max_length=40, required=False, allow_blank=True)
    sellerEmail = serializers.EmailField(required=False, allow_null=True, allow_blank=True)
    meetup = MeetupSerializer(required=False)
    availableFrom = serializers.DateField(required=False, allow_null=True)
    availableUntil = serializers.DateField(required=False, allow_null=True)
    imageUrls = serializers.ListField(
        child=serializers.URLField(max_length=1200),
        required=False,
        allow_empty=True,
        max_length=8,
    )

    def validate(self, attrs):
        if (
            attrs.get("availableFrom")
            and attrs.get("availableUntil")
            and attrs["availableUntil"] < attrs["availableFrom"]
        ):
            raise serializers.ValidationError(
                {"availableUntil": "The end date must be on or after the start date."}
            )
        return attrs


class InquiryInputSerializer(serializers.Serializer):
    senderName = serializers.CharField(max_length=120)
    senderPhone = PhoneField(max_length=40, required=False, allow_null=True, allow_blank=True)
    message = serializers.CharField(min_length=5, max_length=2000)
    recipientId = serializers.CharField(max_length=255, required=False, allow_null=True)
