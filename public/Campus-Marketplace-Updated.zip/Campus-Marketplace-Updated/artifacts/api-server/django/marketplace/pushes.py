"""Push notifications through Firebase Cloud Messaging (HTTP v1).

Everything here is a safe no-op until FIREBASE_SERVICE_ACCOUNT_JSON is set on the server, so the
rest of the app works the same with or without Firebase.
"""
import json
import logging
import os
import threading

import requests

logger = logging.getLogger(__name__)
_lock = threading.Lock()
_credentials = None


def _load_credentials():
    global _credentials
    raw = os.environ.get("FIREBASE_SERVICE_ACCOUNT_JSON", "").strip()
    if not raw:
        return None
    with _lock:
        if _credentials is None:
            from google.oauth2 import service_account

            info = json.loads(raw)
            _credentials = (
                service_account.Credentials.from_service_account_info(
                    info, scopes=["https://www.googleapis.com/auth/firebase.messaging"]
                ),
                info["project_id"],
            )
    return _credentials


def _access_token():
    loaded = _load_credentials()
    if not loaded:
        return None, None
    creds, project_id = loaded
    if not creds.valid:
        from google.auth.transport.requests import Request

        creds.refresh(Request())
    return creds.token, project_id


def _deliver(tokens: list[str], title: str, body: str, link: str) -> None:
    from .models import PushToken

    try:
        access_token, project_id = _access_token()
    except Exception:  # noqa: BLE001 - bad credentials must never break the API
        logger.exception("Push: could not authenticate with Firebase")
        return
    if not access_token:
        return
    url = f"https://fcm.googleapis.com/v1/projects/{project_id}/messages:send"
    for token in tokens:
        try:
            response = requests.post(
                url,
                headers={"Authorization": f"Bearer {access_token}"},
                json={"message": {"token": token, "notification": {"title": title, "body": body}, "data": {"link": link}, "android": {"priority": "HIGH"}}},
                timeout=8,
            )
            if response.status_code in (400, 404) and "UNREGISTERED" in response.text or response.status_code == 404:
                PushToken.objects.filter(token=token).delete()
        except requests.RequestException:
            logger.warning("Push: delivery failed for one device")


def send_async(title: str, body: str, link: str, user_id: str | None = None, exclude_user: str | None = None) -> None:
    """Sends to one student's phones (user_id) or to every registered phone (user_id None)."""
    if not os.environ.get("FIREBASE_SERVICE_ACCOUNT_JSON", "").strip():
        return
    from .models import PushToken

    queryset = PushToken.objects.all()
    if user_id:
        queryset = queryset.filter(user_id=user_id)
    if exclude_user:
        queryset = queryset.exclude(user_id=exclude_user)
    tokens = list(queryset.values_list("token", flat=True)[:500])
    if tokens:
        threading.Thread(target=_deliver, args=(tokens, title, body, link), daemon=True).start()
