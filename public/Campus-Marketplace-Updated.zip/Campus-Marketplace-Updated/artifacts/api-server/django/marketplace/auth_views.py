import json
import logging
import os
from urllib.parse import urlencode

from django.http import HttpRequest, HttpResponse, HttpResponseRedirect, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token
import requests

from .models import StudentProfile

logger = logging.getLogger(__name__)

GOOGLE_CLIENT_ID = os.environ.get(
    "GOOGLE_CLIENT_ID",
    "586386198191-djs1r5e71bhv9t0vs9b6gjltjfmdt273.apps.googleusercontent.com"
).strip()

GOOGLE_CLIENT_SECRET = os.environ.get(
    "GOOGLE_CLIENT_SECRET",
    "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"
).strip()

RENDER_EXTERNAL_URL = os.environ.get("RENDER_EXTERNAL_URL", "https://campuscrate-api-1jcb.onrender.com").rstrip("/")
GOOGLE_CALLBACK_URL = f"{RENDER_EXTERNAL_URL}/api/auth/google/callback"
APP_SCHEME = "com.campus.marketplace"
CLERK_SECRET_KEY = os.environ.get("CLERK_SECRET_KEY", "").strip()


def _upsert_google_user(google_sub: str, email: str, name: str, picture: str | None):
    user_id = f"google_{google_sub}"
    try:
        profile, _ = StudentProfile.objects.update_or_create(
            user_id=user_id,
            defaults={
                "email": email,
                "name": name or email.split("@")[0],
                "image_url": picture,
            },
        )
        return profile
    except Exception as exc:
        print(f"[OAUTH] Fallback profile created (DB note: {exc})", flush=True)
        class FallbackProfile:
            pass
        p = FallbackProfile()
        p.user_id = user_id
        p.email = email
        p.name = name or email.split("@")[0]
        p.image_url = picture
        return p


def _get_or_create_clerk_ticket(email: str, name: str) -> str | None:
    if not CLERK_SECRET_KEY:
        return None
    headers = {"Authorization": f"Bearer {CLERK_SECRET_KEY}", "Content-Type": "application/json"}
    try:
        res = requests.get(f"https://api.clerk.com/v1/users?email_address={email}", headers=headers, timeout=6)
        users = res.json() if res.status_code == 200 else []
        if users and isinstance(users, list) and len(users) > 0:
            clerk_user_id = users[0]["id"]
        else:
            parts = name.split(" ", 1)
            first_name = parts[0]
            last_name = parts[1] if len(parts) > 1 else ""
            create_res = requests.post(
                "https://api.clerk.com/v1/users",
                headers=headers,
                json={"email_address": [email], "first_name": first_name, "last_name": last_name, "skip_password_requirement": True},
                timeout=6,
            )
            created = create_res.json()
            clerk_user_id = created.get("id")

        if not clerk_user_id:
            return None

        ticket_res = requests.post(
            "https://api.clerk.com/v1/sign_in_tokens",
            headers=headers,
            json={"user_id": clerk_user_id, "expires_in_seconds": 180},
            timeout=6,
        )
        return ticket_res.json().get("token")
    except Exception as e:
        print(f"[OAUTH] Clerk ticket bridge note: {e}", flush=True)
        return None


def _render_native_return(target_url: str):
    """HTML bridge page: hands control back to Android app and avoids Django's DisallowedRedirect."""
    return HttpResponse(
        f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Signed in · campuscrate</title>
  <style>
    body {{ margin: 0; min-height: 100vh; font-family: system-ui, -apple-system, sans-serif; background: #f9f6f0; color: #213b34; display: flex; align-items: center; justify-content: center; text-align: center; padding: 20px; }}
    .card {{ background: #fffdf8; border: 1px solid #e6e2d8; border-radius: 20px; padding: 32px 24px; max-width: 400px; width: 100%; box-shadow: 0 4px 16px rgba(0,0,0,0.06); }}
    .btn {{ display: block; margin-top: 20px; background: #285f51; color: #fff; text-decoration: none; padding: 14px; border-radius: 12px; font-weight: bold; font-size: 16px; }}
  </style>
</head>
<body>
  <div class="card">
    <h2 style="margin: 0 0 10px;">Signed in!</h2>
    <p style="color: #65766e; margin: 0;">Returning you to campuscrate...</p>
    <a class="btn" href="{target_url}">Open campuscrate</a>
  </div>
  <script>
    window.location.replace("{target_url}");
  </script>
</body>
</html>""",
        content_type="text/html",
        status=200,
    )


def _render_error_page(message: str):
    return HttpResponse(
        f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign in Error</title>
  <style>
    body {{ margin: 0; min-height: 100vh; font-family: system-ui, sans-serif; background: #f9f6f0; color: #213b34; display: flex; align-items: center; justify-content: center; text-align: center; padding: 20px; }}
    .card {{ background: #fffdf8; border: 1px solid #e6e2d8; border-radius: 20px; padding: 32px 24px; max-width: 420px; width: 100%; box-shadow: 0 4px 16px rgba(0,0,0,0.06); }}
    .err-box {{ background: #fef2f2; border: 1px solid #fecaca; border-radius: 10px; padding: 12px; color: #991b1b; font-size: 14px; text-align: left; margin: 16px 0; word-break: break-word; }}
    .btn {{ display: block; background: #285f51; color: #fff; text-decoration: none; padding: 12px; border-radius: 12px; font-weight: bold; font-size: 15px; }}
  </style>
</head>
<body>
  <div class="card">
    <h2 style="margin: 0 0 10px; color: #b91c1c;">Sign-in Could Not Complete</h2>
    <div class="err-box"><b>Reason:</b> {message}</div>
    <a class="btn" href="{APP_SCHEME}://auth?error=auth_failed">Back to App</a>
  </div>
</body>
</html>""",
        content_type="text/html",
        status=200,
    )


@csrf_exempt
def google_oauth_start(request: HttpRequest):
    print(f"[OAUTH] Initiating Google OAuth with client_id={GOOGLE_CLIENT_ID[:20]}...", flush=True)
    if not GOOGLE_CLIENT_ID:
        return JsonResponse({"error": "GOOGLE_CLIENT_ID is not configured."}, status=500)

    is_native = request.GET.get("native") == "1" or "Capacitor" in request.headers.get("User-Agent", "")
    state = "native" if is_native else "web"

    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": GOOGLE_CALLBACK_URL,
        "response_type": "code",
        "scope": "openid email profile",
        "access_type": "offline",
        "prompt": "select_account",
        "state": state,
    }
    google_auth_url = f"https://accounts.google.com/o/oauth2/v2/auth?{urlencode(params)}"
    return HttpResponseRedirect(google_auth_url)


@csrf_exempt
def google_oauth_callback(request: HttpRequest):
    code = request.GET.get("code")
    state = request.GET.get("state", "web")
    error = request.GET.get("error")

    print(f"[OAUTH] Callback received: code={'present' if code else 'absent'}, state={state}, error={error}", flush=True)

    if error or not code:
        err_msg = error or "Authorization code missing."
        return _render_error_page(err_msg)

    try:
        # 1. Exchange code for tokens directly with Google
        token_res = requests.post(
            "https://oauth2.googleapis.com/token",
            data={
                "code": code,
                "client_id": GOOGLE_CLIENT_ID,
                "client_secret": GOOGLE_CLIENT_SECRET,
                "redirect_uri": GOOGLE_CALLBACK_URL,
                "grant_type": "authorization_code",
            },
            timeout=10,
        )
        token_data = token_res.json()
        print(f"[OAUTH] Token response status={token_res.status_code}", flush=True)

        if token_res.status_code != 200:
            desc = token_data.get("error_description") or token_data.get("error") or "Token exchange failed"
            return _render_error_page(f"Google Token Exchange Failed: {desc}")

        # 2. Fetch user profile from Google
        userinfo_res = requests.get(
            "https://www.googleapis.com/oauth2/v3/userinfo",
            headers={"Authorization": f"Bearer {token_data['access_token']}"},
            timeout=10,
        )
        user_info = userinfo_res.json()
        if userinfo_res.status_code != 200:
            return _render_error_page("Failed to fetch user profile from Google.")

        email = user_info.get("email", "")
        name = user_info.get("name", "")
        profile = _upsert_google_user(
            google_sub=user_info["sub"],
            email=email,
            name=name,
            picture=user_info.get("picture"),
        )
        print(f"[OAUTH] Successfully authenticated user: {email}", flush=True)

        # 3. Create ticket and bridge back to Android app
        ticket = _get_or_create_clerk_ticket(email, name)
        ticket_param = f"&ticket={ticket}" if ticket else ""

        target_url = f"{APP_SCHEME}://auth?userId={profile.user_id}{ticket_param}"
        print(f"[OAUTH] Returning to app: {target_url}", flush=True)
        return _render_native_return(target_url)

    except Exception as exc:
        logger.exception("Google OAuth callback exception")
        print(f"[OAUTH EXCEPTION] {exc}", flush=True)
        return _render_error_page(f"Server error: {str(exc)}")


@csrf_exempt
def google_verify_id_token(request: HttpRequest):
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed"}, status=405)

    try:
        data = json.loads(request.body or b"{}")
        token_str = data.get("id_token")
        if not token_str:
            return JsonResponse({"error": "id_token is required."}, status=400)

        google_request = google_requests.Request()
        payload = id_token.verify_oauth2_token(
            token_str,
            google_request,
            GOOGLE_CLIENT_ID,
            clock_skew_in_seconds=10,
        )

        email = payload.get("email", "")
        name = payload.get("name", "")
        profile = _upsert_google_user(
            google_sub=payload["sub"],
            email=email,
            name=name,
            picture=payload.get("picture"),
        )

        ticket = _get_or_create_clerk_ticket(email, name)

        return JsonResponse({
            "status": "ok",
            "userId": profile.user_id,
            "email": profile.email,
            "name": profile.name,
            "picture": profile.image_url,
            "ticket": ticket,
        })
    except ValueError as err:
        return JsonResponse({"error": f"Invalid ID token: {str(err)}"}, status=401)
    except Exception as exc:
        logger.exception("Failed to verify Google ID token")
        return JsonResponse({"error": f"Internal error: {str(exc)}"}, status=500)
