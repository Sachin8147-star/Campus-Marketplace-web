import os

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Creates (or updates) the admin login from ADMIN_USERNAME and ADMIN_PASSWORD."

    def handle(self, *args, **options):
        username = os.environ.get("ADMIN_USERNAME", "").strip()
        password = os.environ.get("ADMIN_PASSWORD", "")
        if not username or not password:
            self.stdout.write("Admin panel: set ADMIN_USERNAME and ADMIN_PASSWORD to enable the login.")
            return
        if len(password) < 10:
            self.stderr.write("Admin panel: ADMIN_PASSWORD must be at least 10 characters. No admin was created.")
            return
        User = get_user_model()
        user, created = User.objects.get_or_create(username=username, defaults={"is_staff": True, "is_superuser": True})
        user.is_staff = True
        user.is_superuser = True
        user.set_password(password)
        user.save()
        self.stdout.write(f"Admin panel: {'created' if created else 'updated'} admin user {username!r}.")
