import json
from datetime import datetime, timedelta, timezone as dt_timezone
import logging
import mimetypes
import os
from urllib.parse import quote, urlparse
from uuid import uuid4

import requests
from django.db.models import Q
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from rest_framework import serializers

from . import pushes
from .clerk_profiles import get_profiles
from .models import Favorite, Inquiry, Listing, Notification, NotificationState, PushToken
from .serializers import InquiryInputSerializer, ListingInputSerializer

logger = logging.getLogger(__name__)
MAX_MEDIA_BYTES = 50 * 1024 * 1024
ALLOWED_MEDIA_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "video/mp4",
    "video/webm",
    "video/ogg",
    "video/quicktime",  # .mov from iPhones and many Android cameras
    "video/3gpp",
    "image/gif",
    "image/bmp",
    "image/avif",
}
# Some pickers report a non-standard name for the same thing.
MIME_ALIASES = {"image/jpg": "image/jpeg", "image/pjpeg": "image/jpeg", "video/x-m4v": "video/mp4"}
EXTENSION_FALLBACK = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp",
    ".mp4": "video/mp4", ".m4v": "video/mp4", ".webm": "video/webm", ".ogg": "video/ogg",
    ".mov": "video/quicktime", ".3gp": "video/3gpp",
    ".jfif": "image/jpeg", ".gif": "image/gif", ".bmp": "image/bmp", ".avif": "image/avif",
}


def _media_type(upload) -> str:
    declared = (upload.content_type or "").split(";")[0].strip().lower()
    declared = MIME_ALIASES.get(declared, declared)
    if declared in ALLOWED_MEDIA_TYPES:
        return declared
    # Empty or generic type (application/octet-stream): fall back to the file extension.
    extension = os.path.splitext(upload.name or "")[1].lower()
    return EXTENSION_FALLBACK.get(extension, declared)


def _student_id(request: HttpRequest) -> str | None:
    value = request.headers.get("X-User-Id", "").strip()
    return value or None


def _unauthorized() -> JsonResponse:
    return JsonResponse({"error": "Sign in to continue."}, status=401)


def _json_body(request: HttpRequest) -> tuple[dict | None, JsonResponse | None]:
    try:
        body = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({"error": "Request body must be valid JSON."}, status=400)
    if not isinstance(body, dict):
        return None, JsonResponse({"error": "Request body must be an object."}, status=400)
    return body, None


def _validation_error(details) -> JsonResponse:
    return JsonResponse({"error": details}, status=400)


def _date_string(value):
    return value.isoformat() if value else None


def _listing_payload(listing: Listing, profile: dict | None = None) -> dict:
    profile = profile or {}
    return {
        "id": listing.id,
        "title": listing.title,
        "description": listing.description,
        "category": listing.category,
        "listingType": listing.listing_type,
        "price": float(listing.price),
        "priceUnit": listing.price_unit,
        "condition": listing.condition,
        "status": listing.status,
        "location": listing.location,
        "imageUrls": listing.image_urls or [],
        "sellerId": listing.seller_id,
        "sellerName": profile.get("name") or listing.seller_name,
        "sellerImageUrl": profile.get("imageUrl"),
        "sellerPhone": profile.get("phone") or listing.seller_phone,
        "sellerEmail": profile.get("email") or listing.seller_email,
        "meetup": listing.meetup or {},
        "availableFrom": _date_string(listing.available_from),
        "availableUntil": _date_string(listing.available_until),
        "createdAt": listing.created_at.isoformat(),
        "updatedAt": listing.updated_at.isoformat(),
    }


def _listing_payloads(listings) -> list[dict]:
    """Serialises many listings with one batched seller-profile lookup."""
    listings = list(listings)
    profiles = get_profiles(listing.seller_id for listing in listings)
    return [_listing_payload(listing, profiles.get(listing.seller_id)) for listing in listings]


def _single_payload(listing: Listing) -> dict:
    return _listing_payloads([listing])[0]


def _inquiry_payload(inquiry: Inquiry, viewer: str | None = None, profiles: dict | None = None) -> dict:
    profile = (profiles or {}).get(inquiry.sender_id) or {}
    return {
        "id": inquiry.id,
        "listingId": inquiry.listing_id,
        "listingTitle": inquiry.listing.title,
        "listingImage": inquiry.listing.image_urls[0] if inquiry.listing.image_urls else None,
        "sellerId": inquiry.listing.seller_id,
        "sellerName": inquiry.listing.seller_name,
        "senderId": inquiry.sender_id,
        "recipientId": inquiry.recipient_id,
        "senderName": profile.get("name") or inquiry.sender_name,
        "senderImageUrl": profile.get("imageUrl"),
        "senderPhone": inquiry.sender_phone,
        "message": inquiry.message,
        "createdAt": inquiry.created_at.isoformat(),
        "isUnread": bool(viewer and inquiry.recipient_id == viewer and inquiry.read_at is None),
    }


def _model_values(data: dict) -> dict:
    field_names = {
        "listingType": "listing_type",
        "priceUnit": "price_unit",
        "sellerName": "seller_name",
        "sellerPhone": "seller_phone",
        "sellerEmail": "seller_email",
        "availableFrom": "available_from",
        "availableUntil": "available_until",
        "imageUrls": "image_urls",
    }
    return {field_names.get(key, key): value for key, value in data.items()}


@csrf_exempt
def health_check(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    return JsonResponse({"status": "ok"})


@csrf_exempt
def list_listings(request: HttpRequest) -> JsonResponse:
    if request.method == "POST":
        student_id = _student_id(request)
        if not student_id:
            return _unauthorized()
        body, error = _json_body(request)
        if error:
            return error
        serializer = ListingInputSerializer(data=body)
        if not serializer.is_valid():
            return _validation_error(serializer.errors)
        values = _model_values(serializer.validated_data)
        # Seller name, photo, e-mail and phone always come from the seller's own profile.
        profile = get_profiles([student_id]).get(student_id) or {}
        values["seller_name"] = profile.get("name") or values.get("seller_name") or "Campus student"
        values["seller_email"] = profile.get("email") or values.get("seller_email") or None
        values["seller_phone"] = profile.get("phone") or values.get("seller_phone") or ""
        if not values["seller_phone"]:
            return _validation_error({"sellerPhone": ["Add a phone number (10 to 15 digits) to your profile first."]})
        meetup = values.get("meetup") or {}
        if meetup.get("place") and not values.get("location"):
            values["location"] = meetup["place"]
        listing = Listing.objects.create(
            seller_id=student_id,
            **values,
        )
        _notify(user_id="*", author_id=student_id, kind="listing", title="New listing on campus", body=f"{listing.title} · ₹{int(listing.price) if float(listing.price).is_integer() else listing.price}", link=f"/listing/{listing.id}")
        return JsonResponse(_single_payload(listing), status=201)

    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)

    listings = Listing.objects.all()
    search = request.GET.get("search", "").strip()
    category = request.GET.get("category", "").strip()
    listing_type = request.GET.get("listingType", "").strip()
    condition = request.GET.get("condition", "").strip()
    status = request.GET.get("status", "").strip()

    if search:
        listings = listings.filter(
            Q(title__icontains=search)
            | Q(description__icontains=search)
            | Q(category__icontains=search)
            | Q(location__icontains=search)
        )
    if category:
        listings = listings.filter(category__iexact=category)
    if listing_type in {"sale", "rent"}:
        listings = listings.filter(listing_type=listing_type)
    if condition in {"new", "like-new", "good", "fair"}:
        listings = listings.filter(condition=condition)
    if status in {"available", "reserved", "sold", "rented"}:
        listings = listings.filter(status=status)
    else:
        listings = listings.filter(status="available")

    sort_by = request.GET.get("sortBy", "newest")
    ordering = {
        "newest": "-created_at",
        "price-low": "price",
        "price-high": "-price",
    }.get(sort_by, "-created_at")
    return JsonResponse(
        _listing_payloads(listings.order_by(ordering)[:100]),
        safe=False,
    )


@csrf_exempt
def listing_detail(request: HttpRequest, listing_id: int) -> JsonResponse:
    try:
        listing = Listing.objects.get(pk=listing_id)
    except Listing.DoesNotExist:
        return JsonResponse({"error": "Listing not found."}, status=404)

    if request.method == "GET":
        return JsonResponse(_single_payload(listing))

    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    if listing.seller_id != student_id:
        return JsonResponse({"error": "Listing not found."}, status=404)

    if request.method == "PATCH":
        body, error = _json_body(request)
        if error:
            return error
        serializer = ListingInputSerializer(data=body, partial=True)
        if not serializer.is_valid():
            return _validation_error(serializer.errors)
        if not serializer.validated_data:
            return JsonResponse({"error": "Provide at least one field to update."}, status=400)
        for field, value in _model_values(serializer.validated_data).items():
            setattr(listing, field, value)
        listing.updated_at = timezone.now()
        listing.save()
        return JsonResponse(_single_payload(listing))

    if request.method == "DELETE":
        listing.delete()
        return HttpResponse(status=204)
    return JsonResponse({"error": "Method not allowed."}, status=405)


@csrf_exempt
def my_listings(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    listings = Listing.objects.filter(seller_id=student_id).order_by("-created_at")
    return JsonResponse(_listing_payloads(listings), safe=False)


@csrf_exempt
def dashboard_summary(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    own_listings = Listing.objects.filter(seller_id=student_id)
    return JsonResponse(
        {
            "activeListings": own_listings.filter(
                status__in=["available", "reserved"]
            ).count(),
            "completedListings": own_listings.filter(
                status__in=["sold", "rented"]
            ).count(),
            "favorites": Favorite.objects.filter(user_id=student_id).count(),
            "newInquiries": Inquiry.objects.filter(
                listing__seller_id=student_id
            ).exclude(sender_id=student_id).count(),
        }
    )


@csrf_exempt
def favorites(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    saved = Listing.objects.filter(favorites__user_id=student_id).order_by("-favorites__created_at")
    return JsonResponse(_listing_payloads(saved), safe=False)


@csrf_exempt
def favorite_detail(request: HttpRequest, listing_id: int) -> JsonResponse:
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    if request.method == "POST":
        try:
            listing = Listing.objects.get(pk=listing_id)
        except Listing.DoesNotExist:
            return JsonResponse({"error": "Listing not found."}, status=404)
        Favorite.objects.get_or_create(user_id=student_id, listing=listing)
        return HttpResponse(status=204)
    if request.method == "DELETE":
        Favorite.objects.filter(user_id=student_id, listing_id=listing_id).delete()
        return HttpResponse(status=204)
    return JsonResponse({"error": "Method not allowed."}, status=405)


@csrf_exempt
def diagnostics(request: HttpRequest) -> JsonResponse:
    """Public, secret-free health details to debug a deployment from a browser."""
    from django.db import connection
    from django.db.migrations.recorder import MigrationRecorder

    info: dict = {"django": True}
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT column_name FROM information_schema.columns WHERE table_name = %s", ["marketplace_inquiry"])
            columns = sorted(row[0] for row in cursor.fetchall())
        info["database"] = True
        info["inquiryColumns"] = columns
        info["inquiryRecipientColumn"] = "recipient_id" in columns
        info["migrationsApplied"] = sorted(
            f"{m.app}.{m.name}" for m in MigrationRecorder.Migration.objects.filter(app="marketplace")
        )
        info["listingCount"] = Listing.objects.count()
    except Exception as exc:  # noqa: BLE001 - reporting the failure is the point
        info["database"] = False
        info["databaseError"] = str(exc)[:200]
    info["storageConfigured"] = bool(os.environ.get("SUPABASE_URL") and os.environ.get("SUPABASE_SERVICE_ROLE_KEY"))
    if info["storageConfigured"]:
        try:
            base = _clean_supabase_url(os.environ["SUPABASE_URL"])
            bucket = os.environ.get("SUPABASE_STORAGE_BUCKET", "campus-listings")
            probe = _storage_request("GET", f"{base}/storage/v1/bucket/{quote(bucket, safe='')}", os.environ["SUPABASE_SERVICE_ROLE_KEY"].strip(), timeout=10)
            info["storageCheck"] = {"status": probe.status_code, "ok": probe.ok, "keyKind": "new" if os.environ["SUPABASE_SERVICE_ROLE_KEY"].strip().startswith("sb_") else "legacy", "detail": "" if probe.ok else probe.text[:160]}
        except Exception as exc:  # noqa: BLE001
            info["storageCheck"] = {"ok": False, "detail": str(exc)[:160]}
    return JsonResponse(info)


def _notify(*, user_id: str, author_id: str, kind: str, title: str, body: str, link: str) -> None:
    """Stores a notification and (when Firebase is configured) pushes it to the phone(s)."""
    try:
        Notification.objects.create(user_id=user_id, author_id=author_id, kind=kind, title=title[:160], body=body[:300], link=link[:255])
        pushes.send_async(title, body[:140], link, user_id=None if user_id == "*" else user_id, exclude_user=author_id)
    except Exception:  # noqa: BLE001 - a notification problem must never break sending a message
        logger.exception("Could not create notification")


@csrf_exempt
def listing_inquiries(request: HttpRequest, listing_id: int) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    try:
        listing = Listing.objects.get(pk=listing_id)
    except Listing.DoesNotExist:
        return JsonResponse({"error": "Listing not found."}, status=404)

    body, error = _json_body(request)
    if error:
        return error
    serializer = InquiryInputSerializer(data=body)
    if not serializer.is_valid():
        return _validation_error(serializer.errors)

    # Determine recipient:
    # 1. If provided in the request (reply case)
    # 2. If student is the seller, find the last inquiry's sender
    # 3. Otherwise, recipient is the seller (first inquiry case)
    recipient_id = body.get("recipientId")
    if not recipient_id:
        if listing.seller_id == student_id:
            # Seller replying, find who sent the last message to this listing
            last_iq = Inquiry.objects.filter(listing=listing).exclude(sender_id=student_id).first()
            if last_iq:
                recipient_id = last_iq.sender_id
            else:
                return JsonResponse({"error": "Original inquirer not found."}, status=400)
        else:
            # Buyer asking, recipient is seller
            recipient_id = listing.seller_id

    inquiry = Inquiry.objects.create(
        listing=listing,
        sender_id=student_id,
        recipient_id=recipient_id,
        sender_name=serializer.validated_data["senderName"],
        sender_phone=serializer.validated_data.get("senderPhone") or None,
        message=serializer.validated_data["message"],
    )
    sender_label = serializer.validated_data["senderName"]
    preview = inquiry.message if len(inquiry.message) <= 100 else inquiry.message[:100] + "…"
    _notify(user_id=recipient_id, author_id=student_id, kind="message", title=f"{sender_label} sent you a message", body=f"{listing.title}: {preview}", link="/inbox")
    return JsonResponse(_inquiry_payload(inquiry, student_id), status=201)


@never_cache
@csrf_exempt
def inquiries(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    items = (
        Inquiry.objects.select_related("listing")
        .filter(Q(sender_id=student_id) | Q(recipient_id=student_id))
        .order_by("-created_at")[:100]
    )
    items = list(items)
    profiles = get_profiles(item.sender_id for item in items)
    return JsonResponse([_inquiry_payload(item, student_id, profiles) for item in items], safe=False)


_STORAGE_VARIANT: dict[str, int] = {}


def _storage_variants(key: str) -> list[dict]:
    """Ways to present the key. Legacy service_role keys are JWTs (both headers). The newer opaque
    sb_secret_... keys normally go in `apikey` only, but we also fall back to sending both."""
    if key.startswith("sb_"):
        return [{"apikey": key}, {"apikey": key, "Authorization": f"Bearer {key}"}]
    return [{"apikey": key, "Authorization": f"Bearer {key}"}]


def _storage_request(method: str, url: str, key: str, headers: dict | None = None, **kwargs):
    """Calls Supabase Storage, trying each way of presenting the key until one is accepted."""
    variants = _storage_variants(key)
    first = _STORAGE_VARIANT.get(key[:16], 0)
    order = [first] + [i for i in range(len(variants)) if i != first]
    response = None
    for index in order:
        response = requests.request(method, url, headers={**variants[index], **(headers or {})}, **kwargs)
        if response.status_code not in (400, 401, 403):
            _STORAGE_VARIANT[key[:16]] = index
            return response
    return response


def _clean_supabase_url(raw: str) -> str:
    url = raw.strip().rstrip("/")
    for suffix in ("/storage/v1", "/rest/v1", "/auth/v1"):
        if url.endswith(suffix):
            url = url[: -len(suffix)]
    return url


def _storage_problem(prefix: str, response) -> str:
    detail = (response.text or "").strip().replace("\n", " ")[:160]
    hint = ""
    if response.status_code in (401, 403):
        hint = " The Supabase key is not accepted: check SUPABASE_SERVICE_ROLE_KEY on the server."
    elif response.status_code == 404:
        hint = " Check SUPABASE_URL (it should look like https://<project>.supabase.co)."
    return f"{prefix} (Supabase answered HTTP {response.status_code}: {detail}).{hint}"


def _allow_media_types_on_bucket(supabase_url: str, bucket: str, key: str) -> None:
    """Best effort: older buckets were created without .mov/.3gp, which Supabase would then reject."""
    try:
        _storage_request(
            "PUT",
            f"{supabase_url}/storage/v1/bucket/{quote(bucket, safe='')}",
            key,
            headers={"Content-Type": "application/json"},
            json={"public": True, "file_size_limit": MAX_MEDIA_BYTES, "allowed_mime_types": sorted(ALLOWED_MEDIA_TYPES)},
            timeout=15,
        )
    except requests.RequestException:
        logger.warning("Could not refresh allowed media types on the Supabase bucket")


def _ensure_public_storage_bucket(supabase_url: str, bucket: str, service_role_key: str) -> JsonResponse | None:
    bucket_url = f"{supabase_url}/storage/v1/bucket/{quote(bucket, safe='')}"
    try:
        response = _storage_request("GET", bucket_url, service_role_key, timeout=15)
        if response.status_code == 404:
            created = _storage_request(
                "POST",
                f"{supabase_url}/storage/v1/bucket",
                service_role_key,
                headers={"Content-Type": "application/json"},
                json={"id": bucket, "name": bucket, "public": True, "file_size_limit": MAX_MEDIA_BYTES, "allowed_mime_types": sorted(ALLOWED_MEDIA_TYPES)},
                timeout=15,
            )
            if created.ok:
                return None
            # A concurrent first upload may have created the bucket: re-read it.
            response = _storage_request("GET", bucket_url, service_role_key, timeout=15)
            if not response.ok:
                logger.warning("Supabase bucket create failed: %s %s", created.status_code, created.text[:200])
                return JsonResponse({"error": _storage_problem("Could not create the photo bucket", created)}, status=502)

        if not response.ok:
            logger.warning("Supabase Storage bucket check failed: status=%s body=%s", response.status_code, response.text[:200])
            return JsonResponse({"error": _storage_problem("Could not verify the Supabase listing photo bucket", response)}, status=502)
        _allow_media_types_on_bucket(supabase_url, bucket, service_role_key)
        if not response.json().get("public", False):
            return JsonResponse({"error": f"The Supabase bucket '{bucket}' is private. Make it public to display listing photos."}, status=502)
    except (requests.RequestException, ValueError):
        logger.exception("Could not verify the Supabase listing photo bucket")
        return JsonResponse({"error": "Could not reach Supabase to verify the photo bucket. Check SUPABASE_URL and the server's internet access."}, status=502)
    return None


@csrf_exempt
def upload_listing_photo(request: HttpRequest) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    if not _student_id(request):
        return _unauthorized()

    photo = request.FILES.get("file")
    if not photo:
        return JsonResponse({"error": "Choose a file to upload."}, status=400)
    media_type = _media_type(photo)
    if media_type not in ALLOWED_MEDIA_TYPES:
        return JsonResponse(
            {"error": "Use a JPG, PNG, WebP, GIF, BMP or AVIF photo, or an MP4, MOV, WebM or OGG video."}, status=400
        )
    if photo.size > MAX_MEDIA_BYTES:
        return JsonResponse({"error": "Files must be 50 MB or smaller."}, status=400)

    supabase_url = _clean_supabase_url(os.environ.get("SUPABASE_URL", ""))
    service_role_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "").strip()
    bucket = os.environ.get("SUPABASE_STORAGE_BUCKET", "campus-listings")
    if not supabase_url or not service_role_key:
        return JsonResponse(
            {
                "error": "Photo storage is not configured yet. Add the Supabase project URL and service role key to Replit Secrets."
            },
            status=503,
        )
    if urlparse(supabase_url).scheme not in {"https", "http"} or not urlparse(supabase_url).netloc:
        return JsonResponse({"error": "Supabase URL is invalid."}, status=503)

    bucket_error = _ensure_public_storage_bucket(
        supabase_url, bucket, service_role_key
    )
    if bucket_error:
        return bucket_error

    extension = mimetypes.guess_extension(media_type) or ".jpg"
    object_path = f"listing-photos/{uuid4().hex}{extension}"
    encoded_bucket = quote(bucket, safe="")
    encoded_path = quote(object_path, safe="/")
    upload_url = f"{supabase_url}/storage/v1/object/{encoded_bucket}/{encoded_path}"
    try:
        response = _storage_request(
            "POST",
            upload_url,
            service_role_key,
            headers={"Content-Type": media_type, "x-upsert": "true", "cache-control": "max-age=3600"},
            data=photo.read(),
            timeout=150,
        )
    except requests.RequestException:
        logger.exception("Supabase Storage upload request failed")
        return JsonResponse({"error": "Could not reach Supabase Storage."}, status=502)

    if not response.ok:
        logger.warning("Supabase Storage rejected a listing photo upload: status=%s", response.status_code)
        return JsonResponse({"error": _storage_problem("Supabase Storage rejected the upload", response)}, status=502)

    image_url = (
        f"{supabase_url}/storage/v1/object/public/"
        f"{encoded_bucket}/{encoded_path}"
    )
    return JsonResponse({"imageUrl": image_url, "path": object_path}, status=201)


@never_cache
@csrf_exempt
def inbox_unread(request: HttpRequest) -> JsonResponse:
    """How many people have unread messages for me, and how many per conversation."""
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    rows = Inquiry.objects.filter(recipient_id=student_id, read_at__isnull=True).values_list("listing_id", "sender_id")
    threads: dict[str, int] = {}
    people: set[str] = set()
    for listing_id, sender_id in rows:
        key = f"{listing_id}-{sender_id}"
        threads[key] = threads.get(key, 0) + 1
        people.add(sender_id)
    return JsonResponse({"people": len(people), "messages": sum(threads.values()), "threads": threads})


@csrf_exempt
def inbox_read(request: HttpRequest) -> JsonResponse:
    """Marks one conversation as read (called when the chat is opened)."""
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    body, error = _json_body(request)
    if error:
        return error
    listing_id, other_id = body.get("listingId"), body.get("otherId")
    if not isinstance(listing_id, int) or not other_id:
        return JsonResponse({"error": "listingId and otherId are required."}, status=400)
    updated = Inquiry.objects.filter(
        recipient_id=student_id, sender_id=other_id, listing_id=listing_id, read_at__isnull=True
    ).update(read_at=timezone.now())
    return JsonResponse({"updated": updated})


def _visible_notifications(student_id: str):
    since = timezone.now() - timedelta(days=30)
    return Notification.objects.filter(Q(user_id=student_id) | Q(user_id="*"), created_at__gte=since).exclude(author_id=student_id)


@never_cache
@csrf_exempt
def notifications(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    # Personal notifications (messages) count from the very beginning; "new listing" broadcasts only count
    # from the first time this student's feed was loaded, so a new account never starts with a pile of old ones.
    state, _ = NotificationState.objects.get_or_create(
        user_id=student_id, defaults={"seen_at": datetime(1970, 1, 1, tzinfo=dt_timezone.utc), "joined_at": timezone.now()}
    )

    def is_new(item) -> bool:
        floor = state.seen_at if item.user_id == student_id else max(state.seen_at, state.joined_at)
        return item.created_at > floor

    items = list(_visible_notifications(student_id)[:50])
    flags = {item.id: is_new(item) for item in items}
    return JsonResponse(
        {
            "unread": sum(flags.values()),
            "items": [
                {
                    "id": item.id,
                    "kind": item.kind,
                    "title": item.title,
                    "body": item.body,
                    "link": item.link,
                    "createdAt": item.created_at.isoformat(),
                    "isNew": flags[item.id],
                }
                for item in items
            ],
        }
    )


@csrf_exempt
def notifications_seen(request: HttpRequest) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    NotificationState.objects.update_or_create(user_id=student_id, defaults={"seen_at": timezone.now()})
    return JsonResponse({"ok": True})


@csrf_exempt
def push_register(request: HttpRequest) -> JsonResponse:
    """Remembers (POST) or forgets (DELETE) this phone's push token."""
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    body, error = _json_body(request)
    if error:
        return error
    token = str(body.get("token") or "").strip()
    if not 20 <= len(token) <= 500:
        return JsonResponse({"error": "A valid token is required."}, status=400)
    if request.method == "POST":
        PushToken.objects.update_or_create(token=token, defaults={"user_id": student_id})
        return JsonResponse({"ok": True}, status=201)
    if request.method == "DELETE":
        PushToken.objects.filter(token=token, user_id=student_id).delete()
        return JsonResponse({"ok": True})
    return JsonResponse({"error": "Method not allowed."}, status=405)


@csrf_exempt
def seller_profile(request: HttpRequest, seller_id: str) -> JsonResponse:
    """Public, read-only profile of a seller plus the things they currently have listed."""
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    profile = get_profiles([seller_id]).get(seller_id) or {}
    listings = Listing.objects.filter(seller_id=seller_id)
    latest = listings.order_by("-created_at").first()
    if not profile and not latest:
        return JsonResponse({"error": "Seller not found."}, status=404)
    available = listings.filter(status="available").order_by("-created_at")[:60]
    return JsonResponse(
        {
            "id": seller_id,
            "name": profile.get("name") or (latest.seller_name if latest else "Campus student"),
            "imageUrl": profile.get("imageUrl"),
            "phone": profile.get("phone") or (latest.seller_phone if latest else None),
            "email": profile.get("email") or (latest.seller_email if latest else None),
            "listingCount": listings.count(),
            "listings": _listing_payloads(available),
        }
    )
