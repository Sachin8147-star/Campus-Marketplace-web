from django.db import models
from django.utils import timezone


class StudentProfile(models.Model):
    """Profile for students signing in via Google OAuth."""
    user_id = models.CharField(max_length=255, primary_key=True)  # e.g. google_<sub_id>
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=255, blank=True, default="")
    image_url = models.URLField(max_length=1000, blank=True, null=True)
    phone = models.CharField(max_length=40, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "student_profiles"

    def __str__(self) -> str:
        return f"{self.name} ({self.email})"


class Listing(models.Model):
    LISTING_TYPES = [("sale", "Sale"), ("rent", "Rent")]
    PRICE_UNITS = [
        ("one-time", "One time"),
        ("day", "Per day"),
        ("week", "Per week"),
        ("month", "Per month"),
    ]
    CONDITIONS = [
        ("new", "New"),
        ("like-new", "Like new"),
        ("good", "Good"),
        ("fair", "Fair"),
    ]
    STATUSES = [
        ("available", "Available"),
        ("reserved", "Reserved"),
        ("sold", "Sold"),
        ("rented", "Rented"),
    ]

    title = models.CharField(max_length=120)
    description = models.TextField(max_length=3000)
    category = models.CharField(max_length=80, db_index=True)
    listing_type = models.CharField(max_length=8, choices=LISTING_TYPES, db_index=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    price_unit = models.CharField(max_length=10, choices=PRICE_UNITS)
    condition = models.CharField(max_length=12, choices=CONDITIONS)
    status = models.CharField(max_length=10, choices=STATUSES, default="available", db_index=True)
    location = models.CharField(max_length=160)
    image_urls = models.JSONField(default=list, blank=True)
    seller_id = models.CharField(max_length=255, db_index=True)
    seller_name = models.CharField(max_length=120)
    seller_phone = models.CharField(max_length=40)
    seller_email = models.EmailField(null=True, blank=True)
    meetup = models.JSONField(default=dict, blank=True)
    available_from = models.DateField(null=True, blank=True)
    available_until = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]


class Favorite(models.Model):
    user_id = models.CharField(max_length=255, db_index=True)
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="favorites")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["user_id", "listing"], name="unique_user_listing_favorite")
        ]
        ordering = ["-created_at"]


class Inquiry(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="inquiries")
    sender_id = models.CharField(max_length=255, db_index=True)
    recipient_id = models.CharField(max_length=255, db_index=True, null=True, blank=True)
    sender_name = models.CharField(max_length=120)
    sender_phone = models.CharField(max_length=40, null=True, blank=True)
    message = models.TextField(max_length=2000)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]


class Notification(models.Model):
    user_id = models.CharField(max_length=255, blank=True, default="")
    author_id = models.CharField(max_length=255, blank=True, default="")
    kind = models.CharField(max_length=20, default="message")
    title = models.CharField(max_length=160)
    body = models.TextField(blank=True, default="")
    link = models.CharField(max_length=255, default="/")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "notifications"
        ordering = ["-created_at"]


class NotificationState(models.Model):
    user_id = models.CharField(max_length=255, primary_key=True)
    seen_at = models.DateTimeField()
    joined_at = models.DateTimeField(default=timezone.now)

    class Meta:
        db_table = "notification_state"


class PushToken(models.Model):
    user_id = models.CharField(max_length=255, db_index=True)
    token = models.CharField(max_length=500, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "push_tokens"


class Report(models.Model):
    user_id = models.CharField(max_length=255, blank=True, default="")
    contact = models.TextField(null=True, blank=True)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    resolved = models.BooleanField(default=False)

    class Meta:
        db_table = "reports"
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"Report #{self.pk}"
