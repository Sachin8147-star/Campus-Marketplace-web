import { pool } from "@workspace/db";

/**
 * Removes everything a student created or received: listings (with the messages, saved items,
 * cart entries and orders attached to them), their own messages, saved items, cart and orders.
 * Reports they filed stay for the team, but are no longer linked to them.
 */
export async function deleteUserData(userId: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const mine = "(SELECT id FROM marketplace_listing WHERE seller_id = $1)";
    await client.query(`DELETE FROM marketplace_inquiry WHERE sender_id = $1 OR recipient_id = $1 OR listing_id IN ${mine}`, [userId]);
    await client.query(`DELETE FROM marketplace_favorite WHERE user_id = $1 OR listing_id IN ${mine}`, [userId]);
    await client.query(`DELETE FROM cart_items WHERE user_id = $1 OR listing_id IN ${mine}`, [userId]);
    await client.query(`DELETE FROM tracking WHERE buyer_id = $1 OR seller_id = $1 OR listing_id IN ${mine}`, [userId]);
    await client.query("UPDATE reports SET user_id = 'deleted-account' WHERE user_id = $1", [userId]);
    // Notifications and push tokens (tables created by the Django migrations).
    for (const [table, where] of [["notifications", "user_id = $1 OR author_id = $1"], ["notification_state", "user_id = $1"], ["push_tokens", "user_id = $1"]] as const) {
      const exists = await client.query("SELECT to_regclass($1) AS t", [table]);
      if (exists.rows[0].t) await client.query(`DELETE FROM ${table} WHERE ${where}`, [userId]);
    }
    await client.query("DELETE FROM marketplace_listing WHERE seller_id = $1", [userId]);
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
