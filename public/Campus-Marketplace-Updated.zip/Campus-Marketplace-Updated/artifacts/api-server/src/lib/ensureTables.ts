import { pool } from "@workspace/db";
import { logger } from "./logger";

/**
 * Cart and hand-off tracking live in Express/Drizzle rather than Django.
 * Creating the tables on start-up means a fresh database "just works" and the
 * Cart / My orders pages never fail with "relation does not exist".
 */
export async function ensureTables(): Promise<void> {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS cart_items (
        id serial PRIMARY KEY,
        user_id text NOT NULL,
        listing_id integer NOT NULL,
        quantity integer NOT NULL DEFAULT 1,
        created_at timestamp NOT NULL DEFAULT now(),
        updated_at timestamp NOT NULL DEFAULT now()
      );
      DO $$ BEGIN
        CREATE TYPE tracking_status AS ENUM ('pending', 'scheduled', 'met', 'completed', 'cancelled');
      EXCEPTION WHEN duplicate_object THEN NULL;
      END $$;
      CREATE TABLE IF NOT EXISTS tracking (
        id serial PRIMARY KEY,
        listing_id integer NOT NULL,
        seller_id text NOT NULL,
        buyer_id text NOT NULL,
        status tracking_status NOT NULL DEFAULT 'pending',
        scheduled_time timestamp,
        location text,
        created_at timestamp NOT NULL DEFAULT now(),
        updated_at timestamp NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS reports (
        id serial PRIMARY KEY,
        user_id text NOT NULL DEFAULT '',
        contact text,
        message text NOT NULL,
        created_at timestamp NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS cart_items_user_idx ON cart_items (user_id);
      CREATE INDEX IF NOT EXISTS tracking_buyer_idx ON tracking (buyer_id);
      CREATE INDEX IF NOT EXISTS tracking_seller_idx ON tracking (seller_id);
    `);
    // Self-heal: older databases were created without Inquiry.recipient_id, which made
    // the inbox and "send message" fail with HTTP 500. No-op when the column exists
    // (or when Django has not created the table yet).
    await pool.query(`
      ALTER TABLE IF EXISTS marketplace_inquiry ADD COLUMN IF NOT EXISTS recipient_id varchar(255) NULL;
      DO $$ BEGIN
        IF to_regclass('marketplace_inquiry') IS NOT NULL THEN
          CREATE INDEX IF NOT EXISTS marketplace_inquiry_recipient_id_idx ON marketplace_inquiry (recipient_id);
        END IF;
      END $$;
    `);
    logger.info("Cart, tracking and inquiry tables are ready");
  } catch (err) {
    logger.error({ err }, "Could not prepare cart/tracking tables - check DATABASE_URL");
  }
}
