import { Router, type IRouter, type Request, type Response } from "express";
import { clerkClient, getAuth } from "@clerk/express";
import { logger } from "../lib/logger";
import { deleteUserData } from "../lib/accountData";

const router: IRouter = Router();

router.get("/whoami", (req: Request, res: Response) => {
  let userId = (req.headers["x-user-id"] as string) || "";
  if (!userId) {
    try {
      userId = getAuth(req).userId ?? "";
    } catch {
      userId = "";
    }
  }
  res.json({ signedIn: Boolean(userId), userId: userId || null });
});

function frontendApiHost(publishableKey: string): string | null {
  const encoded = publishableKey.split("_").slice(2).join("_");
  try {
    const decoded = Buffer.from(encoded, "base64").toString("utf8").replace(/\$$/, "");
    return /^[a-z0-9.-]+$/i.test(decoded) ? decoded : null;
  } catch {
    return null;
  }
}

/** Fallback web tab for APK sign-in. Google button goes to direct Google OAuth; email uses Clerk. */
router.get("/auth/native", (_req: Request, res: Response) => {
  const publishableKey = process.env.CLERK_PUBLISHABLE_KEY ?? "";
  const host = frontendApiHost(publishableKey);
  if (!publishableKey || !host) {
    res.status(500).type("text/plain").send("Sign-in is not configured on the server.");
    return;
  }
  const scriptSrc = `https://${host}/npm/@clerk/clerk-js@5/dist/clerk.browser.js`;
  res
    .type("html")
    .setHeader("Cache-Control", "no-store")
    .send(`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Sign in · campuscrate</title>
<style>
  body { margin: 0; min-height: 100vh; font-family: system-ui, sans-serif; background: #f9f6f0; color: #213b34; display: flex; flex-direction: column; }
  header { background: #2c5249; color: #fff; padding: 22px 22px 56px; }
  main { flex: 1; margin-top: -30px; background: #f9f6f0; border-radius: 26px 26px 0 0; padding: 22px 14px 32px; display: flex; flex-direction: column; align-items: center; }
  .gbtn { display: flex; align-items: center; justify-content: center; gap: 12px; width: 100%; max-width: 420px; height: 52px; border: 1px solid #d9ded5; border-radius: 14px; background: #fff; color: #213b34; font: 600 16px system-ui, sans-serif; box-shadow: 0 1px 2px rgb(0 0 0 / .05); cursor: pointer; }
  .gwrap { width: 100%; max-width: 420px; margin: 0 auto 18px; text-align: center; }
  .or { display: flex; align-items: center; gap: 12px; margin: 16px 0 0; color: #65766e; font-size: 13px; }
  .or::before, .or::after { content: ''; flex: 1; height: 1px; background: #e6e2d8; }
  #clerk { width: 100%; display: flex; justify-content: center; }
</style>
</head>
<body>
<header><b>campus<span>crate</span></b><p>Good things find <em>good people.</em></p></header>
<main>
  <div id="gwrap" class="gwrap">
    <!-- Direct Google OAuth button (No Clerk) -->
    <button id="gbtn" class="gbtn" type="button" onclick="window.location.href='/api/auth/google?native=1'">
      <svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.5-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>
      Continue with Google
    </button>
    <div class="or">or sign in with email</div>
  </div>
  <div id="clerk"></div>
</main>
<script>
  // Email login stays on Clerk as requested
  var s = document.createElement('script');
  s.async = true; s.crossOrigin = 'anonymous';
  s.setAttribute('data-clerk-publishable-key', ${JSON.stringify(publishableKey)});
  s.src = ${JSON.stringify(scriptSrc)};
  s.onload = async function() {
    await window.Clerk.load({ appearance: { elements: { socialButtonsRoot: { display: 'none' }, dividerRow: { display: 'none' } } } });
    window.Clerk.mountSignIn(document.getElementById('clerk'), { appearance: { elements: { socialButtonsRoot: { display: 'none' }, dividerRow: { display: 'none' } } } });
  };
  document.head.appendChild(s);
</script>
</body>
</html>`);
});

router.delete("/account", async (req: Request, res: Response) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to continue." });
    return;
  }
  try {
    await deleteUserData(userId);
  } catch (err) {
    logger.error({ err }, "Could not delete account data");
    res.status(500).json({ error: "Could not delete your data." });
    return;
  }
  try {
    await clerkClient.users.deleteUser(userId);
  } catch {
    /* ignore if user is a Google-only profile */
  }
  res.status(204).end();
});

export default router;
