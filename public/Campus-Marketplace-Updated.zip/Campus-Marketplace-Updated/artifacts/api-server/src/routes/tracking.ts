import { Router } from "express";
import { db, pool, trackingTable } from "@workspace/db";
import { eq, or, and } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const tracking = await db.select()
      .from(trackingTable)
      .where(or(eq(trackingTable.sellerId, userId), eq(trackingTable.buyerId, userId)));
    res.json(tracking);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch tracking info" });
  }
});

router.post("/", async (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { listingId, scheduledTime, location } = req.body ?? {};
  if (!listingId) {
    res.status(400).json({ error: "Listing ID is required" });
    return;
  }

  try {
    // The seller comes from the listing itself, never from the client.
    const found = await pool.query("SELECT seller_id FROM marketplace_listing WHERE id = $1", [listingId]);
    if (found.rowCount === 0) {
      res.status(404).json({ error: "That listing no longer exists." });
      return;
    }
    const sellerId = found.rows[0].seller_id as string;
    if (sellerId === userId) {
      res.status(403).json({ code: "OWN_LISTING", error: "You listed this item, so you can't place an order for it." });
      return;
    }
    const inserted = await db.insert(trackingTable)
      .values({
        listingId,
        sellerId,
        buyerId: userId,
        scheduledTime: scheduledTime ? new Date(scheduledTime) : null,
        location,
        status: "pending"
      })
      .returning();
    res.status(201).json(inserted[0]);
  } catch (error) {
    res.status(500).json({ error: "Failed to create tracking" });
  }
});

router.patch("/:id", async (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const id = parseInt(req.params.id);
  const { status, scheduledTime, location } = req.body ?? {};

  try {
    const updated = await db.update(trackingTable)
      .set({
        ...(status && { status }),
        ...(scheduledTime && { scheduledTime: new Date(scheduledTime) }),
        ...(location && { location }),
        updatedAt: new Date()
      })
      .where(and(eq(trackingTable.id, id), or(eq(trackingTable.sellerId, userId), eq(trackingTable.buyerId, userId))))
      .returning();

    if (updated.length === 0) {
      res.status(404).json({ error: "Tracking not found" });
      return;
    }
    res.json(updated[0]);
  } catch (error) {
    res.status(500).json({ error: "Failed to update tracking" });
  }
});

export default router;
