import { Router } from "express";
import { db, pool, cartItemsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  try {
    const items = await db.select().from(cartItemsTable).where(eq(cartItemsTable.userId, userId));
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch cart items" });
  }
});

router.post("/", async (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const { listingId, quantity } = req.body ?? {};
  if (!listingId) {
    res.status(400).json({ error: "Listing ID is required" });
    return;
  }

  try {
    // Rule: a seller can never put their own listing in their cart.
    const found = await pool.query("SELECT seller_id, status FROM marketplace_listing WHERE id = $1", [listingId]);
    if (found.rowCount === 0) {
      res.status(404).json({ error: "That listing no longer exists." });
      return;
    }
    if (found.rows[0].seller_id === userId) {
      res.status(403).json({ code: "OWN_LISTING", error: "You listed this item, so you can't add it to your own cart." });
      return;
    }
    if (found.rows[0].status !== "available") {
      res.status(409).json({ error: "This item is no longer available." });
      return;
    }

    const existing = await db.select()
      .from(cartItemsTable)
      .where(and(eq(cartItemsTable.userId, userId), eq(cartItemsTable.listingId, listingId)))
      .limit(1);

    // Used items are one-of-a-kind: adding twice must not create "quantity 2".
    if (existing.length > 0) {
      res.json({ ...existing[0], alreadyInCart: true });
      return;
    }

    const inserted = await db.insert(cartItemsTable)
      .values({ userId, listingId, quantity: quantity || 1 })
      .returning();
    res.status(201).json(inserted[0]);
  } catch (error) {
    res.status(500).json({ error: "Failed to add item to cart" });
  }
});

router.delete("/:id", async (req, res) => {
  const userId = req.headers["x-user-id"] as string;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const id = parseInt(req.params.id);
  try {
    await db.delete(cartItemsTable).where(and(eq(cartItemsTable.id, id), eq(cartItemsTable.userId, userId)));
    res.status(204).end();
  } catch (error) {
    res.status(500).json({ error: "Failed to remove item from cart" });
  }
});

export default router;
