import express, { Router, type IRouter } from "express";
import healthRouter from "./health";
import cartRouter from "./cart";
import trackingRouter from "./tracking";
import authRouter from "./auth";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
// JSON bodies are parsed only for these Express-owned routes. A global parser
// would consume the request stream before the Django proxy (uploads!) sees it.
router.use("/cart", express.json(), cartRouter);
router.use("/tracking", express.json(), trackingRouter);
router.use("/reports", express.json(), reportsRouter);

export default router;
