import { Router } from "express";
import { pool } from "@workspace/db";

const router = Router();

/** "Report a problem" from the Help page. Stored in the reports table for the team to read. */
router.post("/", async (req, res) => {
  const userId = (req.headers["x-user-id"] as string) || "";
  const message = String(req.body?.message ?? "").trim();
  const contact = String(req.body?.contact ?? "").trim().slice(0, 200);
  if (message.length < 10) {
    res.status(400).json({ error: "Please describe the problem in at least 10 characters." });
    return;
  }
  try {
    await pool.query("INSERT INTO reports (user_id, contact, message) VALUES ($1, $2, $3)", [userId, contact || null, message.slice(0, 3000)]);
    res.status(201).json({ ok: true });
  } catch {
    res.status(500).json({ error: "Could not save your report. Please try again." });
  }
});

export default router;
