import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import app from "./app";
import { logger } from "./lib/logger";
import { ensureTables } from "./lib/ensureTables";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const djangoDirectory = fileURLToPath(new URL("../django/", import.meta.url));
const isProduction = process.env.NODE_ENV === "production";
const djangoArgs = isProduction
  ? [
      "-m",
      "gunicorn",
      "config.wsgi:application",
      "--bind",
      "127.0.0.1:8765",
      "--workers",
      "2",
      "--timeout",
      "180",
      "--access-logfile",
      "-",
      "--error-logfile",
      "-",
    ]
  : ["manage.py", "runserver", "127.0.0.1:8765", "--noreload"];
function findPython(): string {
  const candidates = [process.env.PYTHON_EXECUTABLE, "python3", "python", "py"].filter(
    (value): value is string => Boolean(value),
  );
  for (const candidate of candidates) {
    const probe = spawnSync(candidate, ["--version"], { encoding: "utf8" });
    if (!probe.error && probe.status === 0) return candidate;
  }
  throw new Error(
    "Python was not found. Install Python 3.12+ (or set PYTHON_EXECUTABLE in .env) and run: pip install django djangorestframework gunicorn \"psycopg[binary]\" requests",
  );
}

const python = findPython();

// Make sure the marketplace tables exist before serving traffic (idempotent).
const migrate = spawnSync(python, ["manage.py", "migrate", "--noinput"], {
  cwd: djangoDirectory,
  env: { ...process.env, PYTHONUNBUFFERED: "1" },
  stdio: "inherit",
});
if (migrate.status !== 0) {
  logger.error("Django migrate failed - check DATABASE_URL and SESSION_SECRET in .env");
}

// Admin panel: collect its design files and create/update the admin login from the environment.
for (const args of [["collectstatic", "--noinput", "-v", "0"], ["ensure_admin"]]) {
  const step = spawnSync(python, ["manage.py", ...args], { cwd: djangoDirectory, env: { ...process.env, PYTHONUNBUFFERED: "1" }, stdio: "inherit" });
  if (step.status !== 0) logger.warn(`manage.py ${args[0]} did not finish cleanly`);
}

const djangoProcess = spawn(python, djangoArgs, {
  cwd: djangoDirectory,
  env: { ...process.env, PYTHONUNBUFFERED: "1" },
  stdio: "inherit",
});

djangoProcess.on("error", (err) => {
  logger.error({ err }, "Could not start Django marketplace service");
  process.exit(1);
});

const stopDjango = () => {
  if (djangoProcess.exitCode === null) djangoProcess.kill("SIGTERM");
};
process.once("SIGINT", stopDjango);
process.once("SIGTERM", stopDjango);

async function waitForDjango(): Promise<void> {
  const timeoutAt = Date.now() + 45_000;
  while (Date.now() < timeoutAt) {
    if (djangoProcess.exitCode !== null) {
      throw new Error(`Django exited with code ${djangoProcess.exitCode}`);
    }
    try {
      const response = await fetch("http://127.0.0.1:8765/api/healthz", {
        signal: AbortSignal.timeout(1_000),
      });
      if (response.ok) return;
    } catch {
      // Django is still starting; retry until the startup deadline.
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error("Django did not become healthy within 45 seconds.");
}

async function startServer(): Promise<void> {
  await ensureTables();
  try {
    await waitForDjango();
  } catch (err) {
    logger.error({ err }, "Django marketplace service failed to start");
    if (isProduction) {
      stopDjango();
      process.exit(1);
    }
    // In development keep the gateway up so the app shows a clear "service unavailable" message.
  }

  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      stopDjango();
      process.exit(1);
    }

    logger.info({ port }, "API gateway listening");
  });
}

void startServer();
