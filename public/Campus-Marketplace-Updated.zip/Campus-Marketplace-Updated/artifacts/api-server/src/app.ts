import express, {
  type Express,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import { ServerResponse } from "node:http";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware, getAuth } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import { createProxyMiddleware } from "http-proxy-middleware";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// Clerk's production frontend-API proxy (kept intact for email login)
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());

app.use(
  cors({
    credentials: true,
    origin: true,
    allowedHeaders: ["Content-Type", "Authorization", "Accept", "X-User-Id"],
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    maxAge: 86400,
  }),
);

app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

// Middleware to inject X-User-Id header for all /api requests
app.use("/api", (req: Request, res: Response, next: NextFunction) => {
  if (
    req.path.startsWith("/admin") ||
    req.path.startsWith("/static") ||
    req.path.startsWith("/auth/google")
  ) {
    next();
    return;
  }

  // 1. Check for direct User ID or Bearer token
  let userId = (req.headers["x-user-id"] as string) || "";

  if (!userId && req.headers.authorization?.startsWith("Bearer ")) {
    const raw = req.headers.authorization.slice(7).trim();
    if (raw.startsWith("google_")) {
      userId = raw;
    }
  }

  // 2. Fall back to Clerk (for email login)
  if (!userId) {
    try {
      userId = getAuth(req).userId ?? "";
    } catch {
      userId = "";
    }
  }

  req.headers["x-user-id"] = userId;

  const isReadOnly = ["GET", "HEAD", "OPTIONS"].includes(req.method);
  if (!isReadOnly && !userId) {
    res.status(401).json({ error: "Sign in to continue." });
    return;
  }
  next();
});

// Use Express routes for local features like cart and tracking
app.use("/api", router);

// Proxy everything else to the Django marketplace service
app.use(
  createProxyMiddleware({
    target: "http://127.0.0.1:8765",
    changeOrigin: true,
    pathFilter: (pathname) =>
      pathname === "/api" || pathname.startsWith("/api/"),
    on: {
      proxyReq(proxyReq, req) {
        const userId = req.headers["x-user-id"];
        if (typeof userId === "string" && userId) {
          proxyReq.setHeader("X-User-Id", userId);
        } else {
          proxyReq.removeHeader("X-User-Id");
        }
      },
      error(error, _req, res) {
        logger.error({ err: error }, "Django marketplace service proxy failed");
        if (res instanceof ServerResponse) {
          if (!res.headersSent) {
            res.writeHead(502, { "content-type": "application/json" });
          }
          res.end(JSON.stringify({ error: "Marketplace service is unavailable." }));
        } else {
          res.destroy(error);
        }
      },
    },
  }),
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((err: unknown, _req: Request, res: Response, next: NextFunction) => {
  logger.error({ err }, "Unhandled gateway error");
  if (res.headersSent) {
    next(err);
    return;
  }
  const status =
    typeof (err as { status?: unknown })?.status === "number"
      ? ((err as { status: number }).status as number)
      : 500;
  res.status(status).json({ error: status === 400 ? "Invalid request." : "Something went wrong on the server." });
});

export default app;
