@echo off
REM One-click APK build (needs Android Studio / SDK installed, as you already have).
REM 1) Put your deployed backend in .env  ->  VITE_API_BASE_URL=https://your-backend
cd /d %~dp0
call pnpm install
cd artifacts\campus-marketplace
call pnpm run build:apk
cd android
call gradlew.bat assembleDebug
echo.
echo APK: artifacts\campus-marketplace\android\app\build\outputs\apk\debug\app-debug.apk
pause
