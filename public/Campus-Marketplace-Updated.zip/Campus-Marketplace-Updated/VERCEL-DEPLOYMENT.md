# How to Host Campus Crate Frontend on Vercel

Your backend is already live on Render (`https://campuscrate-api-1jcb.onrender.com`).
Both your Android APK and your Website frontend use this same backend.

---

## Option 1: Deploy Directly via GitHub (Recommended)

1. **Push this project to a GitHub repository** (public or private).
2. Go to **[vercel.com](https://vercel.com)** and sign in.
3. Click **"Add New..."** -> **"Project"**.
4. Import your GitHub repository.
5. In the **Configure Project** screen:
   - **Framework Preset**: Vite
   - **Root Directory**: Click `Edit` and select `artifacts/campus-marketplace`
     *(Or if you deploy the standalone `Campus-Marketplace-Frontend-Vercel`, the root directory is just `./`)*
   - **Build Command**: `npm run build` or `vite build`
   - **Output Directory**: `dist` (or `dist/public`)
6. **Environment Variables**:
   Under **Environment Variables**, add:
   - Name: `VITE_API_BASE_URL`
     Value: `https://campuscrate-api-1jcb.onrender.com`
   - Name: `VITE_CLERK_PUBLISHABLE_KEY`
     Value: `pk_test_bW9kZXJuLWZlcnJldC05NTY0LmNsZXJrLmFjY291bnRzLmRldiQ`
7. Click **"Deploy"**.
   Vercel will build and launch your website with a free HTTPS URL (e.g., `https://your-app.vercel.app`).

---

## Option 2: Deploy Using the Vercel CLI

1. Open your terminal in the frontend directory (`artifacts/campus-marketplace` or the standalone frontend folder):
   ```bash
   cd artifacts/campus-marketplace
   ```
2. Install the Vercel CLI (if not already installed):
   ```bash
   npm i -g vercel
   ```
3. Run:
   ```bash
   vercel
   ```
4. Follow the on-screen prompts:
   - Set up and deploy? **Yes**
   - Which scope? Select your personal or team account
   - Link to existing project? **No**
   - Project name? **campuscrate** (or any name you prefer)
   - In which directory is your code located? **./**
5. Add environment variables when prompted or in the Vercel project dashboard.
6. For production deployment:
   ```bash
   vercel --prod
   ```

---

## Features Shared Between Website & APK
- **Single Live Database**: Any listing posted on the website immediately appears in the APK, and vice versa.
- **Cart & Orders**: Cart items and orders are saved to the student's account and stay in sync across devices.
- **Real-time Messages & Inbox**: Unread badges and message history work across both web and APK.
- **Media Uploads**: Photos and videos are stored in Supabase storage and display on both platforms.
