# What changed

Frontend
- Listings now load for signed-in users too (the "/" page used to redirect to My listings).
- Backend address is configurable: `VITE_API_BASE_URL` in `.env`, or in-app Profile > Server settings (no rebuild needed). The old hard-coded 192.168.1.40 is gone.
- Android app sends the Clerk token as a Bearer header, so cart / saved / upload / inbox work.
- HTML-instead-of-JSON responses are now treated as errors (no more silent "Nothing on this shelf yet").
- Photo/video upload rewritten: progress bars, image compression, mov/3gp support, clear error messages.
- Profile icon (top right) opens a profile-only menu; bottom Profile tab opens a full Swiggy-style profile page (Account, My orders, Cart, Listings, Saved, Messages, Help, Server settings, Sign out). New pages: /account, /orders, /help.
- Bottom bar is 5 tabs (Explore, Saved, Sell, Inbox, Profile); Cart is the header icon.

Backend
- Cart/tracking POST bodies were never parsed (express.json ran after the routes) - fixed.
- Cart/tracking tables and Django migrations are created automatically on start.
- Finds `python`/`python3`/`py` (Windows fix), CORS allows the app, longer upload timeouts, more video types.

# Run locally
pnpm install
pnpm --filter @workspace/api-server run dev      (API on PORT from .env)
pnpm --filter @workspace/campus-marketplace run dev   (set API_PROXY_TARGET if API is not on :5000)

# Build the APK
1. Deploy the backend somewhere public (Render etc.) and set VITE_API_BASE_URL in .env.
2. Double-click build-apk.bat  (or push to GitHub: .github/workflows/build-apk.yml builds it).
3. APK: artifacts/campus-marketplace/android/app/build/outputs/apk/debug/app-debug.apk

# Update 2
- FIX message sending / inbox HTTP 500: added migration 0002_inquiry_recipient (the recipient_id column was missing in the database). Render applies it automatically on the next deploy.
- The Android app now connects to the live backend by default (DEFAULT_API_URL in src/lib/api-config.ts). Server settings is only an advanced option.
- UI pass on every page (mobile + desktop): compact "Good finds" strip, new sign-in/sign-up mobile layout, listing action buttons, card price/location alignment, order card, branded 404, back-link overlap, long titles.

# Update 3
- Message/inbox: migration 0002 is now idempotent and the API self-heals the missing column on start. Open /api/diag on your server to see database + migration status. Errors in the app now say what went wrong.
- Google sign-in on Android now happens in a real browser tab (Clerk's prebuilt form does not work inside a WebView) and returns to the app through a one-time sign-in ticket (routes/auth.ts).
- Seller name, photo, email and phone come from the seller's Clerk profile; listings store hand-over place, address parts, photo and time window (migration 0003).
- Sellers cannot add their own listing to the cart (checked on the server too); duplicate-order confirmation; back button; scroll to top; footer only on Explore; Privacy and Terms pages; new categories; phone/pincode validation; larger text; Server settings removed.

# Update 4
- FIX Save/unsave: the "wrong server" check wrongly rejected empty 204 answers, so saves worked on the server but the app showed an error and reverted. Fixed in lib/api-client-react/src/custom-fetch.ts.
- Admin panel at /api/admin/ (reports, listings, messages, saved items). Needs ADMIN_USERNAME and ADMIN_PASSWORD on Render.
- Delete account (Account details -> Delete account) removes the student's data and their Clerk account.
- Sign-out confirmation, Join opens Sign in, Back keeps the Profile scroll position, "Last updated" lines removed.

# Update 5
- Red dots: Inbox icon shows how many people messaged you (4+ cap); each person in the inbox shows their unread count (99+ cap). Opening a chat marks it read.
- Notifications: bell icon + page (9+ cap) for new messages and new listings; pop-ups while the app is open; real phone push once Firebase is configured (see DEPLOY-RENDER.md).
- After sending a message the form stays; only a pop-up confirms it.
- Tapping the seller opens their read-only profile (/seller/:id).
- New logo (crate with a heart), including favicon and Android launcher icons.

# Update 6
- Back button: redirects (Saved -> Sign in) no longer create a loop; after sign-in the history is reset, so Back at Explore leaves the app.
- Notification permission no longer crashes the app: push is only switched on in builds that contain Firebase (scripts/build-apk.mjs decides).
- Google sign-in: every attempt starts signed out and always shows Google's "Choose an account" screen.
- Photo upload: understands both kinds of Supabase keys and reports Supabase's real error. /api/diag now includes a storageCheck.
- Red dots: personal notifications count from the first load; dots refresh on every page change and when the app returns to the foreground.
