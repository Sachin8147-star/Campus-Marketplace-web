import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Hosted databases (Render, Supabase, ...) require SSL; a local one does not.
const dbUrl = new URL(process.env.DATABASE_URL);
const isLocalDb = ["localhost", "127.0.0.1", "::1"].includes(dbUrl.hostname);
const sslMode = dbUrl.searchParams.get("sslmode");
const useSsl = !isLocalDb && sslMode !== "disable";

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL.replace(/[?&]sslmode=[^&]*/g, ""),
  ssl: useSsl ? { rejectUnauthorized: false } : undefined,
});
export const db = drizzle(pool, { schema });

export * from "./schema";
