import { pgTable, text, serial, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

export const cartItemsTable = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  listingId: integer("listing_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertCartItemSchema = createInsertSchema(cartItemsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const selectCartItemSchema = createSelectSchema(cartItemsTable);
export type CartItem = typeof cartItemsTable.$inferSelect;
export type InsertCartItem = typeof cartItemsTable.$inferInsert;

export const trackingStatusEnum = pgEnum("tracking_status", ["pending", "scheduled", "met", "completed", "cancelled"]);

export const trackingTable = pgTable("tracking", {
  id: serial("id").primaryKey(),
  listingId: integer("listing_id").notNull(),
  sellerId: text("seller_id").notNull(),
  buyerId: text("buyer_id").notNull(),
  status: trackingStatusEnum("status").notNull().default("pending"),
  scheduledTime: timestamp("scheduled_time"),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertTrackingSchema = createInsertSchema(trackingTable).omit({ id: true, createdAt: true, updatedAt: true });
export const selectTrackingSchema = createSelectSchema(trackingTable);
export type Tracking = typeof trackingTable.$inferSelect;
export type InsertTracking = typeof trackingTable.$inferInsert;
