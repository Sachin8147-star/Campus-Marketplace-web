# Backend ko Render pe deploy karna

1. Project ko GitHub pe push karo (private repo). `.env` file push mat karna (.gitignore me hona chahiye).
2. render.com -> New + -> Blueprint -> apna repo chuno. Render `render.yaml` padh lega.
   (Ya New + -> Web Service -> repo -> Runtime: Docker.)
3. Environment Variables bharo (values apni .env se copy karo):
   - DATABASE_URL            (Render Postgres ka Internal URL, same region me hoga to)
   - SESSION_SECRET          (koi bhi lamba random text)
   - CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY
   - SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY
   - SUPABASE_STORAGE_BUCKET = campus-listings
   - NODE_ENV = production
4. Deploy dabao. 5-10 minute lagte hain. Logs me "API gateway listening" aana chahiye.
5. Service ka URL kholo: https://<naam>.onrender.com/api/healthz  ->  {"status":"ok"}
6. Wahi URL app me: Profile -> Server settings (ya .env me VITE_API_BASE_URL, phir APK dobara).

# Admin panel (reports)
Add two more environment variables on Render, then redeploy:
   - ADMIN_USERNAME   (any name you like)
   - ADMIN_PASSWORD   (at least 10 characters, make it strong)
Open https://<your-service>.onrender.com/api/admin/ and sign in. Reports sent from the app's
Help -> Report tab appear under "Reports" (mark them resolved there).

# Push notifications (optional, for notifications when the app is closed)
Without this, notifications still appear inside the app (bell icon, red dots, pop-ups while the app is open).
To also get them on the phone's notification bar when the app is closed:
1. console.firebase.google.com -> Add project. Add an Android app with package name com.campus.marketplace.
2. Download google-services.json and put it in artifacts/campus-marketplace/android/app/  (do NOT commit secrets you don't need to; this file is not secret but keep the repo private).
3. Firebase -> Project settings -> Service accounts -> Generate new private key. Paste the WHOLE JSON as the Render environment variable FIREBASE_SERVICE_ACCOUNT_JSON.
4. Rebuild the APK (pnpm run build:apk, then gradlew assembleDebug). Allow notifications when the app asks.
