import { useMemo, useState } from "react";
import {
  ArrowDownUp,
  ArrowRight,
  Bike,
  BookOpen,
  Check,
  Clock3,
  Heart,
  Laptop,
  MapPin,
  PackageCheck,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Tag,
} from "lucide-react";

type Listing = {
  id: number;
  title: string;
  category: string;
  condition: string;
  price: number;
  unit?: string;
  location: string;
  seller: string;
  type: "sale" | "rent";
  art: string;
  mark: string;
};

const listings: Listing[] = [
  {
    id: 1,
    title: "Calculus: Early Transcendentals",
    category: "Books",
    condition: "Like new",
    price: 480,
    location: "North hostel",
    seller: "Aarav",
    type: "sale",
    art: "book",
    mark: "8th edition",
  },
  {
    id: 2,
    title: "Casio scientific calculator",
    category: "Calculators",
    condition: "Good",
    price: 65,
    unit: "week",
    location: "Engineering block",
    seller: "Mira",
    type: "rent",
    art: "calc",
    mark: "fx-991EX",
  },
  {
    id: 3,
    title: "Single-speed campus cycle",
    category: "Cycles",
    condition: "Good",
    price: 3200,
    location: "West gate",
    seller: "Dev",
    type: "sale",
    art: "cycle",
    mark: "ready to ride",
  },
  {
    id: 4,
    title: "Intro to Organic Chemistry",
    category: "Books",
    condition: "Like new",
    price: 360,
    location: "Library steps",
    seller: "Nisha",
    type: "sale",
    art: "chem",
    mark: "6th edition",
  },
];

const categories = [
  { label: "All finds", icon: Sparkles },
  { label: "Books", icon: BookOpen },
  { label: "Lab gear", icon: PackageCheck },
  { label: "Calculators", icon: Laptop },
  { label: "Cycles", icon: Bike },
  { label: "Hostel essentials", icon: PackageCheck },
];

function CampusCrateHome() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All finds");
  const [mode, setMode] = useState<"all" | "sale" | "rent">("all");
  const [saved, setSaved] = useState<number[]>([]);
  const [sortLowFirst, setSortLowFirst] = useState(false);

  const visibleListings = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return listings
      .filter((item) => category === "All finds" || item.category === category)
      .filter((item) => mode === "all" || item.type === mode)
      .filter(
        (item) =>
          !needle ||
          `${item.title} ${item.category} ${item.location}`.toLowerCase().includes(needle),
      )
      .sort((a, b) => (sortLowFirst ? a.price - b.price : a.id - b.id));
  }, [category, mode, query, sortLowFirst]);

  const toggleSaved = (id: number) => {
    setSaved((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  };

  return (
    <main className="cc-page">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
        .cc-page {
          --cc-ink: #203b34;
          --cc-green: #285f51;
          --cc-green-deep: #214e43;
          --cc-muted: #718078;
          --cc-paper: #faf8f1;
          --cc-card: #fffdf8;
          --cc-line: #e6e1d5;
          --cc-coral: #dc7957;
          min-height: 100dvh;
          color: var(--cc-ink);
          background: var(--cc-paper);
          font-family: 'DM Sans', sans-serif;
          overflow: hidden;
        }
        .cc-page * { box-sizing: border-box; }
        .cc-topbar {
          height: 76px;
          display: flex;
          align-items: center;
          padding: 0 max(32px, calc((100vw - 1376px)/2));
          border-bottom: 1px solid var(--cc-line);
          background: rgba(250,248,241,.95);
          position: relative;
          z-index: 2;
        }
        .cc-brand { display: flex; align-items: center; gap: 10px; text-decoration: none; color: var(--cc-ink); }
        .cc-brand-mark {
          width: 34px; height: 34px; padding: 8px 7px; display: flex; flex-direction: column;
          justify-content: center; gap: 3px; background: var(--cc-green); border-radius: 11px 11px 11px 4px;
          transform: rotate(-2deg);
        }
        .cc-brand-mark i { height: 3px; display: block; border-radius: 4px; background: #f2d7a3; }
        .cc-brand-mark i:nth-child(2) { width: 76%; background: #e98867; }
        .cc-brand-mark i:nth-child(3) { width: 55%; background: #fbf4e4; }
        .cc-brand-name { font: 800 18px/1 'Manrope', sans-serif; letter-spacing: -1px; }
        .cc-brand-name span { color: var(--cc-coral); }
        .cc-brand-name small { display: block; margin-top: 4px; color: #78847c; font: 600 8px/1 'DM Sans', sans-serif; letter-spacing: .1em; }
        .cc-nav { display: flex; gap: 32px; align-items: center; margin-left: auto; margin-right: 44px; }
        .cc-nav a { color: #68776f; font-size: 12px; font-weight: 700; text-decoration: none; transition: color .18s; }
        .cc-nav a:hover, .cc-nav a.active { color: var(--cc-green); }
        .cc-nav a.active { position: relative; }
        .cc-nav a.active:after { content: ''; position: absolute; height: 2px; bottom: -28px; left: 0; right: 0; background: var(--cc-coral); border-radius: 4px; }
        .cc-header-action { display: flex; align-items: center; gap: 10px; }
        .cc-signin { color: var(--cc-ink); text-decoration: none; font-size: 11px; font-weight: 700; padding: 10px 13px; }
        .cc-button {
          min-height: 40px; padding: 0 16px; border: 0; border-radius: 11px; cursor: pointer;
          display: inline-flex; align-items: center; justify-content: center; gap: 8px;
          background: var(--cc-green); color: #fffaf0; text-decoration: none; font: 700 11px 'DM Sans', sans-serif;
          box-shadow: 0 5px 13px rgba(40,95,81,.15); transition: background .18s, transform .18s;
        }
        .cc-button:hover { background: var(--cc-green-deep); transform: translateY(-1px); }
        .cc-hero {
          max-width: 1376px; min-height: 414px; margin: auto; padding: 44px 0 40px;
          display: grid; grid-template-columns: 1fr .87fr; align-items: center; position: relative;
        }
        .cc-hero-copy { position: relative; z-index: 1; padding: 0 0 18px 0; }
        .cc-eyebrow { display: inline-flex; align-items: center; gap: 9px; color: var(--cc-green); font-size: 9px; font-weight: 800; letter-spacing: .16em; }
        .cc-eyebrow:before { content: ''; width: 25px; height: 1px; background: var(--cc-coral); }
        .cc-hero h1 {
          max-width: 620px; margin: 18px 0 13px; font: 800 clamp(45px, 5vw, 67px)/.99 'Manrope', sans-serif;
          letter-spacing: -.075em; color: var(--cc-ink);
        }
        .cc-hero h1 em { color: var(--cc-green); font-style: normal; }
        .cc-lede { max-width: 436px; margin: 0 0 21px; color: var(--cc-muted); font-size: 13px; line-height: 1.65; }
        .cc-search {
          width: min(100%, 472px); height: 53px; display: flex; align-items: center; gap: 12px;
          padding: 5px 6px 5px 15px; border: 1px solid #e4dfd2; border-radius: 13px;
          background: var(--cc-card); box-shadow: 0 9px 23px rgba(32,59,52,.055); color: #829087;
        }
        .cc-search input { min-width: 0; flex: 1; border: 0; outline: 0; background: transparent; color: var(--cc-ink); font: 500 11px 'DM Sans', sans-serif; }
        .cc-search input::placeholder { color: #929b94; }
        .cc-search button { height: 40px; padding: 0 18px; border: 0; border-radius: 9px; background: var(--cc-coral); color: #fffaf3; font: 800 10px 'DM Sans', sans-serif; cursor: pointer; transition: background .18s; }
        .cc-search button:hover { background: #c96546; }
        .cc-proof { display: flex; align-items: center; gap: 8px; margin-top: 15px; color: #75827a; font-size: 9px; font-weight: 600; }
        .cc-proof svg { color: var(--cc-green); }
        .cc-proof .dot { width: 4px; height: 4px; border-radius: 50%; margin: 0 2px; background: #b4bcb5; }
        .cc-art { height: 344px; display: flex; position: relative; align-items: center; justify-content: center; }
        .cc-orbit { position: absolute; width: 362px; height: 260px; border: 1px solid rgba(40,95,81,.2); border-radius: 50%; transform: rotate(-24deg); }
        .cc-orbit:after { content: ''; position: absolute; inset: -31px 29px; border: 1px dashed rgba(40,95,81,.15); border-radius: 50%; transform: rotate(50deg); }
        .cc-sun { position: absolute; width: 103px; height: 103px; top: 18px; right: 81px; border-radius: 50%; background: #ead39f; opacity: .78; }
        .cc-book {
          position: relative; z-index: 1; width: 177px; height: 236px; padding: 20px;
          display: flex; flex-direction: column; color: #fbf1db; border-radius: 7px 16px 16px 7px;
          background: linear-gradient(105deg, #285f51 0%, #285f51 91%, #1e4e43 91%);
          box-shadow: 16px 18px 34px rgba(30,63,54,.2), inset 6px 0 rgba(255,255,255,.08);
          transform: rotate(6deg);
        }
        .cc-book:before { content: ''; position: absolute; left: 12px; top: 14px; bottom: 14px; width: 1px; background: rgba(252,242,218,.22); }
        .cc-book-kicker { margin-left: 8px; font-size: 7px; letter-spacing: .17em; font-weight: 700; color: #efd59d; }
        .cc-book strong { margin: auto 0 auto 8px; font: 800 29px/.94 'Manrope', sans-serif; letter-spacing: -.08em; }
        .cc-book small { margin-left: 8px; font-size: 8px; letter-spacing: .12em; }
        .cc-tag {
          position: absolute; z-index: 2; top: 30px; left: 77px; width: 79px; height: 70px;
          display: grid; place-content: center; text-align: center; background: var(--cc-coral); color: #fff5e7;
          clip-path: polygon(0 0,100% 0,100% 77%,50% 100%,0 77%); font-size: 8px; line-height: 1.3; letter-spacing: .09em; font-weight: 800; transform: rotate(-9deg);
        }
        .cc-sticker { position: absolute; right: 41px; bottom: 28px; z-index: 2; width: 78px; height: 78px; display: grid; place-content: center; border-radius: 50%; background: #f0d9a8; color: var(--cc-green); text-align: center; font: 800 12px/1 'Manrope', sans-serif; transform: rotate(9deg); }
        .cc-art-note { position: absolute; left: 35px; bottom: 28px; color: #718078; font: 600 9px/1.5 'DM Sans', sans-serif; }
        .cc-hero-foot { position: absolute; bottom: 0; left: 0; right: 0; height: 37px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--cc-line); color: #7b877f; font-size: 8px; font-weight: 800; letter-spacing: .13em; }
        .cc-hero-foot span { display: flex; align-items: center; gap: 8px; }
        .cc-hero-foot i { width: 5px; height: 5px; border-radius: 50%; background: var(--cc-coral); }
        .cc-market {
          border-top: 1px solid rgba(230,225,213,.72);
          background: #f3f0e7;
          padding: 34px max(32px, calc((100vw - 1376px)/2)) 46px;
        }
        .cc-market-head { display: flex; justify-content: space-between; align-items: end; margin-bottom: 19px; }
        .cc-market-title .cc-eyebrow { font-size: 8px; }
        .cc-market-title h2 { margin: 8px 0 0; color: var(--cc-ink); font: 800 31px/1.04 'Manrope', sans-serif; letter-spacing: -.06em; }
        .cc-market-title h2 em { color: var(--cc-green); font-style: normal; }
        .cc-market-note { margin: 0 2px 3px 0; color: var(--cc-muted); font-size: 10px; line-height: 1.55; text-align: right; }
        .cc-categories { display: flex; gap: 8px; overflow-x: auto; padding: 0 0 13px; scrollbar-width: none; }
        .cc-categories::-webkit-scrollbar { display: none; }
        .cc-category {
          min-height: 36px; flex: 0 0 auto; display: inline-flex; align-items: center; gap: 7px; padding: 0 12px;
          border: 1px solid #e2ddcf; border-radius: 10px; background: #fbf9f2; color: #6e7c73; cursor: pointer;
          font: 700 9px 'DM Sans', sans-serif; transition: background .18s, color .18s, border-color .18s;
        }
        .cc-category:hover { border-color: rgba(40,95,81,.5); color: var(--cc-green); }
        .cc-category.active { background: var(--cc-green); border-color: var(--cc-green); color: #fbf5e9; }
        .cc-controls { display: flex; justify-content: space-between; align-items: center; padding: 12px 0 15px; border-top: 1px solid #e2ddcf; }
        .cc-tabs { display: inline-flex; gap: 3px; padding: 3px; border-radius: 9px; background: #e9e6dc; }
        .cc-tabs button { min-height: 28px; padding: 0 11px; display: inline-flex; align-items: center; gap: 6px; border: 0; border-radius: 7px; background: transparent; color: #738077; cursor: pointer; font: 700 9px 'DM Sans', sans-serif; }
        .cc-tabs button.active { color: var(--cc-ink); background: #fffdf8; box-shadow: 0 2px 6px rgba(32,59,52,.07); }
        .cc-sort { display: inline-flex; align-items: center; gap: 7px; border: 0; background: none; color: #637268; cursor: pointer; font: 700 9px 'DM Sans', sans-serif; }
        .cc-listings { display: grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap: 15px; }
        .cc-listing { min-width: 0; position: relative; overflow: hidden; border: 1px solid #e7e2d7; border-radius: 14px; background: var(--cc-card); box-shadow: 0 4px 13px rgba(32,59,52,.035); transition: transform .2s, box-shadow .2s; }
        .cc-listing:hover { transform: translateY(-3px); box-shadow: 0 12px 24px rgba(32,59,52,.09); }
        .cc-product-art { height: 145px; position: relative; display: grid; place-items: center; overflow: hidden; }
        .cc-product-art.book { background: #e8dcc4; }
        .cc-product-art.calc { background: #dce5dc; }
        .cc-product-art.cycle { background: #ead9cb; }
        .cc-product-art.chem { background: #e6dfc9; }
        .cc-art-disc { width: 166px; height: 166px; position: absolute; right: -51px; bottom: -89px; border-radius: 50%; background: rgba(40,95,81,.12); }
        .cc-product-object { position: relative; z-index: 1; width: 104px; height: 119px; display: grid; place-content: center; border-radius: 7px 12px 12px 7px; background: #456c58; color: #f8edda; box-shadow: 10px 12px 20px rgba(32,59,52,.16); transform: rotate(-7deg); }
        .cc-product-object:before { content: ''; position: absolute; top: 8px; bottom: 8px; left: 9px; width: 1px; background: rgba(255,255,255,.25); }
        .cc-product-object span { margin-left: 9px; font: 800 12px/1.05 'Manrope',sans-serif; text-align: left; letter-spacing: -.04em; }
        .cc-product-art.calc .cc-product-object { width: 72px; height: 105px; border-radius: 8px; background: #3f554d; transform: rotate(5deg); }
        .cc-product-art.calc .cc-product-object span { font-size: 7px; letter-spacing: .02em; }
        .cc-product-art.calc .cc-product-object:after { content: ''; position: absolute; height: 28px; left: 14px; right: 12px; top: 17px; border-radius: 3px; background: #b8c8a4; }
        .cc-product-art.cycle .cc-product-object { width: 112px; height: 112px; border-radius: 50%; background: transparent; box-shadow: none; color: #315b4d; transform: rotate(-8deg); }
        .cc-product-art.cycle .cc-product-object:before { display: none; }
        .cc-product-art.cycle .cc-product-object svg { width: 85px; height: 85px; stroke-width: 1.2; }
        .cc-product-art.chem .cc-product-object { background: #be7254; }
        .cc-badge { position: absolute; z-index: 2; top: 10px; left: 10px; padding: 6px 8px; border-radius: 6px; background: rgba(255,253,248,.94); color: var(--cc-green); font-size: 8px; font-weight: 800; }
        .cc-badge.rent { color: #a3553c; }
        .cc-save { position: absolute; z-index: 2; top: 9px; right: 9px; width: 29px; height: 29px; display: grid; place-items: center; border: 1px solid rgba(255,253,248,.85); border-radius: 50%; background: rgba(255,253,248,.94); color: #39544a; cursor: pointer; transition: color .18s, transform .18s; }
        .cc-save:hover, .cc-save.saved { color: var(--cc-coral); transform: scale(1.06); }
        .cc-card-copy { padding: 11px 12px 10px; }
        .cc-card-meta { display: flex; gap: 6px; align-items: center; color: #7b877f; font-size: 8px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; }
        .cc-card-meta b { color: var(--cc-coral); }
        .cc-card-copy h3 { min-height: 34px; margin: 7px 0 9px; color: var(--cc-ink); font: 700 12px/1.35 'Manrope',sans-serif; letter-spacing: -.025em; }
        .cc-card-bottom { display: flex; justify-content: space-between; align-items: baseline; gap: 8px; }
        .cc-card-bottom strong { color: var(--cc-green); font: 800 14px 'Manrope', sans-serif; white-space: nowrap; }
        .cc-card-bottom small { color: #7b877f; font: 600 8px 'DM Sans',sans-serif; }
        .cc-location { display: inline-flex; align-items: center; gap: 3px; color: #738078; font-size: 8px; white-space: nowrap; }
        .cc-seller { min-height: 28px; margin-top: 8px; padding-top: 7px; display: flex; align-items: center; gap: 6px; border-top: 1px solid #eee9de; color: #7b877f; font-size: 8px; }
        .cc-seller i { width: 19px; height: 19px; display: grid; place-items: center; border-radius: 50%; background: #eee2c8; color: var(--cc-green); font-style: normal; font-size: 8px; font-weight: 800; }
        .cc-seller svg { margin-left: auto; color: var(--cc-green); }
        .cc-empty { grid-column: 1 / -1; padding: 30px; text-align: center; border: 1px dashed #d8d3c6; border-radius: 14px; background: rgba(255,253,248,.62); color: var(--cc-muted); font-size: 12px; }
        .cc-empty b { display: block; margin-bottom: 5px; color: var(--cc-ink); font: 700 15px 'Manrope',sans-serif; }
        .cc-footer-note { display: flex; justify-content: center; align-items: center; gap: 7px; margin-top: 22px; color: #77847b; font-size: 9px; font-weight: 600; }
        .cc-footer-note svg { color: var(--cc-coral); }
        @media (max-width: 1100px) {
          .cc-hero, .cc-market { padding-left: 32px; padding-right: 32px; }
          .cc-hero { min-height: 390px; grid-template-columns: 1fr .72fr; }
          .cc-art { transform: scale(.87); }
          .cc-listings { grid-template-columns: repeat(2,minmax(0,1fr)); }
        }
        @media (max-width: 700px) {
          .cc-topbar { height: 66px; padding: 0 18px; }
          .cc-nav { display: none; }
          .cc-header-action { margin-left: auto; }
          .cc-signin { display: none; }
          .cc-button { min-height: 36px; padding: 0 12px; font-size: 10px; }
          .cc-hero { display: flex; flex-direction: column; align-items: stretch; min-height: 0; padding: 38px 20px 0; }
          .cc-hero-copy { padding-bottom: 0; }
          .cc-hero h1 { font-size: clamp(43px, 12vw, 60px); }
          .cc-lede { font-size: 12px; max-width: 390px; }
          .cc-search { height: 50px; }
          .cc-search input { font-size: 10px; }
          .cc-search button { height: 38px; padding: 0 13px; }
          .cc-proof { font-size: 8px; }
          .cc-art { height: 260px; margin: -3px 0 29px; transform: scale(.77); transform-origin: center; }
          .cc-orbit { width: 330px; }
          .cc-hero-foot { bottom: 0; left: 20px; right: 20px; height: 32px; font-size: 6px; }
          .cc-hero-foot span { gap: 4px; }
          .cc-market { padding: 31px 20px 34px; }
          .cc-market-head { align-items: start; gap: 10px; }
          .cc-market-title h2 { font-size: 27px; }
          .cc-market-note { max-width: 132px; font-size: 9px; }
          .cc-category { min-height: 34px; padding: 0 10px; font-size: 8px; }
          .cc-controls { gap: 8px; align-items: flex-start; flex-direction: column; }
          .cc-tabs button { min-height: 27px; padding: 0 9px; font-size: 8px; }
          .cc-listings { grid-template-columns: repeat(2,minmax(0,1fr)); gap: 10px; }
          .cc-product-art { height: 120px; }
          .cc-product-object { transform: scale(.84) rotate(-7deg); }
          .cc-card-copy { padding: 10px; }
          .cc-card-copy h3 { font-size: 11px; min-height: 31px; }
          .cc-card-bottom { align-items: flex-start; flex-direction: column; gap: 4px; }
          .cc-card-bottom strong { font-size: 13px; }
          .cc-location { font-size: 7px; }
        }
        @media (prefers-reduced-motion: reduce) {
          .cc-page *, .cc-page *:before, .cc-page *:after { transition-duration: .01ms !important; }
        }
      `}</style>
      <header className="cc-topbar">
        <a className="cc-brand" href="#top" aria-label="campuscrate home">
          <span className="cc-brand-mark"><i /><i /><i /></span>
          <span className="cc-brand-name">campus<span>crate</span><small>GOOD THINGS, PASSED ON</small></span>
        </a>
        <nav className="cc-nav" aria-label="Main navigation">
          <a href="#browse" className="active">Explore</a>
          <a href="#browse">Saved {saved.length > 0 && `(${saved.length})`}</a>
          <a href="#how">How it works</a>
        </nav>
        <div className="cc-header-action">
          <a className="cc-signin" href="#browse">Sign in</a>
          <a className="cc-button" href="#browse">List an item <ArrowRight size={14} /></a>
        </div>
      </header>

      <section className="cc-hero" id="top">
        <div className="cc-hero-copy">
          <span className="cc-eyebrow">THE CAMPUS CIRCULAR</span>
          <h1>Find the things<br />that <em>get you there.</em></h1>
          <p className="cc-lede">Good books, lab gear, and the little things that make campus life work — from someone just down the hall.</p>
          <form className="cc-search" onSubmit={(event) => { event.preventDefault(); document.getElementById("cc-browse")?.scrollIntoView({ behavior: "smooth" }); }}>
            <Search size={17} />
            <input aria-label="Search campus finds" placeholder="Try “engineering maths” or “cycle”" value={query} onChange={(event) => setQuery(event.target.value)} />
            <button type="submit">Search</button>
          </form>
          <div className="cc-proof"><ShieldCheck size={14} /> Student-to-student, campus-close <span className="dot" /> <span>Good finds, trusted neighbours</span></div>
        </div>
        <div className="cc-art" aria-label="Campuscrate field notes illustration">
          <div className="cc-orbit" />
          <div className="cc-sun" />
          <div className="cc-book"><span className="cc-book-kicker">FIELD NOTES</span><strong>THE<br />GOOD<br />FIND</strong><small>NO. 04&nbsp; / &nbsp;CAMPUS</small></div>
          <div className="cc-tag">PASS IT<br />FORWARD</div>
          <div className="cc-sticker">useful<br />is beautiful</div>
          <div className="cc-art-note">Every item has<br />another semester in it.</div>
        </div>
        <div className="cc-hero-foot"><span><i /> 01 &nbsp; FIND</span><span><i /> 02 &nbsp; CONNECT</span><span><i /> 03 &nbsp; KEEP IT MOVING</span></div>
      </section>

      <section className="cc-market" id="cc-browse">
        <div className="cc-market-head">
          <div className="cc-market-title"><span className="cc-eyebrow">THE GOOD STUFF, NEARBY</span><h2>What are you <em>looking for?</em></h2></div>
          <p className="cc-market-note">Browse what your campus community<br />has ready for its next owner.</p>
        </div>
        <div className="cc-categories" aria-label="Filter by category">
          {categories.map(({ label, icon: Icon }) => (
            <button key={label} className={`cc-category ${category === label ? "active" : ""}`} onClick={() => setCategory(label)}>
              <Icon size={14} />{label}
            </button>
          ))}
        </div>
        <div className="cc-controls">
          <div className="cc-tabs" aria-label="Filter by listing type">
            <button className={mode === "all" ? "active" : ""} onClick={() => setMode("all")}>Everything</button>
            <button className={mode === "sale" ? "active" : ""} onClick={() => setMode(mode === "sale" ? "all" : "sale")}><Tag size={12} /> For sale</button>
            <button className={mode === "rent" ? "active" : ""} onClick={() => setMode(mode === "rent" ? "all" : "rent")}><Clock3 size={12} /> For rent</button>
          </div>
          <button className="cc-sort" onClick={() => setSortLowFirst((current) => !current)}><SlidersHorizontal size={13} /><span>Price {sortLowFirst ? "low to high" : "just added"}</span><ArrowDownUp size={12} /></button>
        </div>
        <div className="cc-listings">
          {visibleListings.length ? visibleListings.map((item) => (
            <article className="cc-listing" key={item.id}>
              <div className={`cc-product-art ${item.art}`}>
                <div className="cc-art-disc" />
                <span className={`cc-badge ${item.type === "rent" ? "rent" : ""}`}>{item.type === "rent" ? "For rent" : "For sale"}</span>
                <button className={`cc-save ${saved.includes(item.id) ? "saved" : ""}`} aria-label={saved.includes(item.id) ? "Remove from saved" : "Save listing"} onClick={() => toggleSaved(item.id)}>
                  <Heart size={15} fill={saved.includes(item.id) ? "currentColor" : "none"} />
                </button>
                <div className="cc-product-object">
                  {item.art === "cycle" ? <Bike /> : <span>{item.mark}</span>}
                </div>
              </div>
              <div className="cc-card-copy">
                <div className="cc-card-meta"><span>{item.category}</span><b>·</b><span>{item.condition}</span></div>
                <h3>{item.title}</h3>
                <div className="cc-card-bottom">
                  <strong>₹{item.price.toLocaleString("en-IN")}<small>{item.unit ? ` / ${item.unit}` : ""}</small></strong>
                  <span className="cc-location"><MapPin size={11} />{item.location}</span>
                </div>
                <div className="cc-seller"><i>{item.seller.slice(0, 1)}</i><span>From {item.seller}</span><Check size={12} /></div>
              </div>
            </article>
          )) : <div className="cc-empty"><b>No finds on this shelf yet.</b>Try another search or category — the good stuff moves quickly.</div>}
        </div>
        <div className="cc-footer-note"><Sparkles size={13} /> Less waste, more campus life. Every time.</div>
      </section>
    </main>
  );
}

export default CampusCrateHome;
