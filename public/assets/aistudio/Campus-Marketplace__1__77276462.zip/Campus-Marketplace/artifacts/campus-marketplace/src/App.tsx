import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn, SignUp, useClerk, useUser } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  ArrowDownWideNarrow, ArrowLeft, ArrowRight, BookOpen, Bike, Check, ChevronDown, CircleHelp,
  Clock3, Compass, Heart, Inbox, Laptop, MapPin, Menu, MessageCircle, PackageCheck, Plus,
  Search, ShieldCheck, SlidersHorizontal, Sparkles, Tag, Trash2, Upload, X,
} from 'lucide-react';
import {
  getGetDashboardSummaryQueryKey, getGetFavoritesQueryKey, getGetInquiriesQueryKey,
  getGetListingQueryKey, getGetMyListingsQueryKey, getListListingsQueryKey, useAddFavorite,
  useCreateInquiry, useCreateListing, useDeleteListing, useGetDashboardSummary, useGetFavorites,
  useGetInquiries, useGetListing, useGetMyListings, useHealthCheck, useListListings,
  useRemoveFavorite, useUpdateListing,
} from '@workspace/api-client-react';
import type { Inquiry, Listing, ListingInput, ListingStatus } from '@workspace/api-client-react';
import { Link, Redirect, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 20_000, retry: 1 } } });
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

function stripBase(path: string) {
  return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path;
}

const appearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: {
    colorPrimary: '#285f51', colorForeground: '#213b34', colorMutedForeground: '#65766e',
    colorDanger: '#b74b42', colorBackground: '#fffdf8', colorInput: '#f7f4eb',
    colorInputForeground: '#213b34', colorNeutral: '#d9ded5', fontFamily: 'DM Sans',
    borderRadius: '1rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#fffdf8] rounded-[24px] w-[440px] max-w-full overflow-hidden shadow-xl',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#213b34] font-bold',
    headerSubtitle: 'text-[#65766e]',
    socialButtonsBlockButtonText: 'text-[#213b34] font-semibold',
    formFieldLabel: 'text-[#29473e] font-semibold',
    footerActionLink: 'text-[#285f51] font-semibold',
    footerActionText: 'text-[#65766e]',
    dividerText: 'text-[#65766e]',
    identityPreviewEditButton: 'text-[#285f51]',
    formFieldSuccessText: 'text-[#285f51]',
    alertText: 'text-[#8e3b34]',
    logoBox: 'mb-3',
    logoImage: 'rounded-xl',
    socialButtonsBlockButton: 'rounded-xl border-[#d9ded5] bg-[#fbfaf5]',
    formButtonPrimary: 'rounded-xl bg-[#285f51] hover:bg-[#1d4d41] text-[#fffdf8]',
    formFieldInput: 'rounded-xl border-[#d9ded5] bg-[#f7f4eb] text-[#213b34]',
    footerAction: 'border-t border-[#e6e2d8]',
    dividerLine: 'bg-[#e6e2d8]',
    alert: 'rounded-xl',
    otpCodeFieldInput: 'rounded-lg border-[#d9ded5]',
    formFieldRow: 'gap-2',
    main: 'gap-5',
  },
};

const categories = ['All finds', 'Books', 'Lab gear', 'Calculators', 'Cycles', 'Hostel essentials'];
const categoryIcons: Record<string, typeof BookOpen> = {
  Books: BookOpen, 'Lab gear': CircleHelp, Calculators: Laptop, Cycles: Bike, 'Hostel essentials': PackageCheck,
};
const categoryOptions = ['Books', 'Lab gear', 'Calculators', 'Cycles', 'Hostel essentials'];
const conditionLabels: Record<string, string> = { new: 'New', 'like-new': 'Like new', good: 'Good', fair: 'Fair' };
const statusLabels: Record<string, string> = { available: 'Available', reserved: 'Reserved', sold: 'Sold', rented: 'Rented' };

function currency(value: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(value);
}

function useInvalidateMarketplace(listingId?: number) {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: getListListingsQueryKey() });
    void qc.invalidateQueries({ queryKey: getGetMyListingsQueryKey() });
    void qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    void qc.invalidateQueries({ queryKey: getGetFavoritesQueryKey() });
    void qc.invalidateQueries({ queryKey: getGetInquiriesQueryKey() });
    if (listingId !== undefined) void qc.invalidateQueries({ queryKey: getGetListingQueryKey(listingId) });
  };
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" data-testid="link-brand" className="brand flex items-center gap-2.5">
      <span className="brand-mark"><span></span><span></span><span></span></span>
      {!compact && <span className="brand-name">campus<span>crate</span><small>good things, passed on</small></span>}
    </Link>
  );
}

function Header() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const [menuOpen, setMenuOpen] = useState(false);
  const name = user?.firstName || 'Student';
  return (
    <header className="site-header">
      <div className="header-inner">
        <Brand />
        <nav className={`nav-links ${menuOpen ? 'nav-open' : ''}`} aria-label="Main navigation">
          <Link href="/" className="nav-link" data-testid="link-marketplace">Explore</Link>
          <Show when="signed-in">
            <Link href="/saved" className="nav-link" data-testid="link-saved"><Heart size={16} /> Saved</Link>
            <Link href="/inbox" className="nav-link" data-testid="link-inbox"><Inbox size={16} /> Inbox</Link>
            <Link href="/dashboard" className="nav-link" data-testid="link-dashboard">My listings</Link>
          </Show>
        </nav>
        <div className="header-actions">
          <Show when="signed-in">
            <Link href="/sell" className="button button-primary button-small" data-testid="link-sell-header"><Plus size={16} /> List an item</Link>
            <div className="profile-menu">
              <span className="avatar">{name.slice(0, 1).toUpperCase()}</span>
              <button type="button" className="profile-name" onClick={() => signOut({ redirectUrl: basePath || '/' })} title="Sign out" data-testid="button-signout">{name}<ChevronDown size={14} /></button>
            </div>
          </Show>
          <Show when="signed-out">
            <Link href="/sign-in" className="button button-quiet button-small" data-testid="link-sign-in-header">Sign in</Link>
            <Link href="/sign-up" className="button button-primary button-small" data-testid="link-sign-up-header">Join campuscrate <ArrowRight size={15} /></Link>
          </Show>
          <button type="button" className="mobile-menu" aria-label="Toggle menu" onClick={() => setMenuOpen(!menuOpen)} data-testid="button-menu"><Menu size={20} /></button>
        </div>
      </div>
    </header>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <div className="market-shell grain"><Header /><ErrorBoundary resetKey={location}>{children}</ErrorBoundary><Footer /></div>;
}

function Footer() {
  return <footer className="site-footer"><div className="footer-inner"><Brand /><p>Useful things find their next chapter here.</p><span>Made for campus, by campus.</span></div></footer>;
}

function HomeRedirect() {
  return <><Show when="signed-in"><Redirect to="/dashboard" /></Show><Show when="signed-out"><Home /></Show></>;
}

function Protected({ children }: { children: ReactNode }) {
  return <><Show when="signed-in">{children}</Show><Show when="signed-out"><Redirect to="/sign-in" /></Show></>;
}

function AppPage({ children }: { children: ReactNode }) {
  return <Shell><main className="page-wrap">{children}</main></Shell>;
}

function Home() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [type, setType] = useState('');
  const [condition, setCondition] = useState('');
  const [sort, setSort] = useState('newest');
  const params = useMemo(() => ({
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(category ? { category } : {}),
    ...(type ? { listingType: type as 'sale' | 'rent' } : {}),
    ...(condition ? { condition: condition as 'new' | 'like-new' | 'good' | 'fair' } : {}),
    status: 'available' as const,
    sortBy: sort as 'newest' | 'price-low' | 'price-high',
  }), [search, category, type, condition, sort]);
  const { data: listings, isLoading, isError, refetch } = useListListings(params);
  const { data: health } = useHealthCheck();
  const rows = listings || [];

  return (
    <Shell>
      <section className="hero">
        <div className="hero-content rise-in">
          <div className="eyebrow"><span className="eyebrow-line"></span> THE CAMPUS CIRCULAR</div>
          <h1>Find the things<br />that <em>get you there.</em></h1>
          <p className="hero-copy">Good books, lab gear, and all the little things that make campus life work — from someone just down the hall.</p>
          <div className="hero-search">
            <Search size={19} />
            <input aria-label="Search listings" data-testid="input-search" placeholder="Try “engineering maths” or “cycle”" value={search} onChange={e => setSearch(e.target.value)} />
            <button onClick={() => document.getElementById('market-grid')?.scrollIntoView({ behavior: 'smooth' })} data-testid="button-search">Search</button>
          </div>
          <div className="hero-meta"><ShieldCheck size={15} /> Student-to-student, campus-close <span className="meta-dot"></span> <span className={`health-dot ${health?.status ? 'is-live' : ''}`}></span> Community listings</div>
        </div>
        <div className="hero-art" aria-label="Campus finds illustration">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="art-sun"></div>
          <div className="art-book"><span>FIELD NOTES</span><b>THE<br />GOOD<br />FIND</b><i>no. 04</i></div>
          <div className="art-tag">PASS IT<br />FORWARD</div>
          <div className="art-sticker">useful<br />is beautiful</div>
          <div className="hero-art-caption">Every item has<br />another semester in it.</div>
        </div>
        <div className="hero-bottom-rule"><span>01 / FIND</span><span>02 / CONNECT</span><span>03 / KEEP IT MOVING</span></div>
      </section>
      <section className="browse-section" id="market-grid">
        <div className="section-heading">
          <div><span className="eyebrow">THE GOOD STUFF, NEARBY</span><h2>What are you <em>looking for?</em></h2></div>
          <p>Browse what your campus community<br className="desktop-only" /> has ready for its next owner.</p>
        </div>
        <div className="category-row" aria-label="Filter by category">
          {categories.map(label => {
            const Icon = categoryIcons[label];
            const value = label === 'All finds' ? '' : label;
            return <button key={label} className={`category-pill ${category === value ? 'selected' : ''}`} onClick={() => setCategory(value)} data-testid={`filter-category-${label.toLowerCase().replaceAll(' ', '-')}`}>{Icon && <Icon size={17} />}{label}</button>;
          })}
        </div>
        <div className="filter-bar">
          <div className="filter-group" aria-label="Listing type">
            <button className={!type ? 'active' : ''} onClick={() => setType('')} data-testid="filter-all">Everything</button>
            <button className={type === 'sale' ? 'active' : ''} onClick={() => setType(type === 'sale' ? '' : 'sale')} data-testid="filter-sale"><Tag size={14} /> For sale</button>
            <button className={type === 'rent' ? 'active' : ''} onClick={() => setType(type === 'rent' ? '' : 'rent')} data-testid="filter-rent"><Clock3 size={14} /> For rent</button>
          </div>
          <div className="filter-selects">
            <label className="select-wrap"><SlidersHorizontal size={15} /><select aria-label="Condition" value={condition} onChange={e => setCondition(e.target.value)} data-testid="select-condition"><option value="">Any condition</option><option value="new">New</option><option value="like-new">Like new</option><option value="good">Good</option><option value="fair">Fair</option></select></label>
            <label className="select-wrap"><ArrowDownWideNarrow size={15} /><select aria-label="Sort listings" value={sort} onChange={e => setSort(e.target.value)} data-testid="select-sort"><option value="newest">Just added</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option></select></label>
          </div>
        </div>
        {isLoading ? <ListingSkeleton /> : isError ? <ErrorState retry={() => void refetch()} /> : rows.length ? (
          <div className="listing-grid">
            {rows.map((item, index) => <ListingCard key={item.id} item={item} index={index} />)}
          </div>
        ) : <EmptyState title="Nothing on this shelf yet." body="Try a different filter, or be the first to put a useful thing back in circulation." action={<Link href="/sell" className="button button-primary" data-testid="link-empty-sell"><Plus size={16} /> List something</Link>} />}
        <div className="browse-footnote"><Sparkles className="small-star" size={14} /> Less waste, more campus life. Every time.</div>
      </section>
      <section className="how-strip"><div className="how-intro"><span className="eyebrow">SIMPLE AS PASSING IT ON</span><h2>Good finds.<br /><em>Good people.</em></h2></div><div className="how-step"><span>01</span><b>Spot your thing</b><p>Search by what you need, then find it close by.</p></div><div className="how-step"><span>02</span><b>Talk to a student</b><p>Ask a question and arrange a hand-off that works.</p></div><div className="how-step"><span>03</span><b>Keep it in play</b><p>Buy or borrow the useful stuff. Give it a next life.</p></div></section>
    </Shell>
  );
}

function ListingSkeleton() {
  return <div className="listing-grid" aria-label="Loading listings">{[0, 1, 2, 3].map(i => <div className="skeleton-card" key={i}><div className="skeleton-image shimmer"></div><div className="skeleton-line shimmer"></div><div className="skeleton-line short shimmer"></div></div>)}</div>;
}

function ErrorState({ retry }: { retry: () => void }) {
  return <div className="state-card error-state"><div className="state-icon"><CircleHelp /></div><h3>We couldn't reach the shelves.</h3><p>Give it a moment, then try again. Your filters are still here.</p><button className="button button-primary" onClick={retry} data-testid="button-retry"><ArrowRight size={16} /> Try again</button></div>;
}

function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return <div className="state-card"><div className="state-icon"><Compass /></div><h3>{title}</h3><p>{body}</p>{action}</div>;
}

function ListingCard({ item, index = 0 }: { item: Listing; index?: number }) {
  const { user } = useUser();
  const [, setLocation] = useLocation();
  const favoritesQuery = useGetFavorites({ query: { enabled: Boolean(user), queryKey: getGetFavoritesQueryKey() } });
  const isSaved = (favoritesQuery.data || []).some(f => f.id === item.id);
  const add = useAddFavorite();
  const remove = useRemoveFavorite();
  const invalidate = useInvalidateMarketplace();
  const busy = add.isPending || remove.isPending;
  const toggle = () => {
    if (!user) { setLocation('/sign-in'); return; }
    if (isSaved) remove.mutate({ id: item.id }, { onSuccess: invalidate });
    else add.mutate({ id: item.id }, { onSuccess: invalidate });
  };
  return (
    <article className={`listing-card rise-in delay-${Math.min(index % 4, 3)}`} data-testid={`card-listing-${item.id}`}>
      <Link href={`/listing/${item.id}`} className="card-image-link" data-testid={`link-listing-${item.id}`}>
        <div className="card-image photo-frame">
          {item.imageUrls?.[0] ? <img src={item.imageUrls[0]} alt={item.title} /> : <FallbackArt category={item.category} />}
          <span className={`type-badge ${item.listingType}`}>{item.listingType === 'rent' ? 'For rent' : 'For sale'}</span>
        </div>
      </Link>
      <button className={`save-button ${isSaved ? 'saved' : ''}`} aria-label={isSaved ? 'Remove from saved' : 'Save listing'} onClick={toggle} disabled={busy} data-testid={`button-save-${item.id}`}><Heart size={17} fill={isSaved ? 'currentColor' : 'none'} /></button>
      <div className="card-body">
        <div className="card-meta"><span>{item.category}</span><span className="meta-separator">·</span><span>{conditionLabels[item.condition] || item.condition}</span></div>
        <Link href={`/listing/${item.id}`} className="card-title" data-testid={`link-title-${item.id}`}>{item.title}</Link>
        <div className="card-bottom"><strong>{currency(item.price)}<small>{item.listingType === 'rent' ? ` / ${item.priceUnit}` : ''}</small></strong><span className="card-location"><MapPin size={13} />{item.location}</span></div>
        <div className="seller-line"><span className="mini-avatar">{item.sellerName.slice(0, 1).toUpperCase()}</span><span>From {item.sellerName}</span><ArrowRight size={14} /></div>
      </div>
    </article>
  );
}

function FallbackArt({ category }: { category: string }) {
  const Icon = categoryIcons[category] || PackageCheck;
  return <div className={`fallback-art art-${category.toLowerCase().replaceAll(' ', '-')}`}><div className="fallback-shape"></div><span className="fallback-icon"><Icon size={47} strokeWidth={1.2} /></span><span className="fallback-label">{category}</span></div>;
}

function ListingDetail({ id }: { id: number }) {
  const { user } = useUser();
  const [, setLocation] = useLocation();
  const { data: item, isLoading, isError, refetch } = useGetListing(id);
  const [message, setMessage] = useState('');
  const [senderPhone, setSenderPhone] = useState('');
  const [notice, setNotice] = useState('');
  const [sent, setSent] = useState(false);
  const createInquiry = useCreateInquiry();
  const add = useAddFavorite();
  const remove = useRemoveFavorite();
  const { data: favorites } = useGetFavorites({ query: { enabled: Boolean(user), queryKey: getGetFavoritesQueryKey() } });
  const invalidate = useInvalidateMarketplace();
  const saved = Boolean(item && favorites?.some(f => f.id === item.id));
  if (isLoading) return <AppPage><div className="detail-skeleton shimmer"></div></AppPage>;
  if (isError || !item) return <AppPage><ErrorState retry={() => void refetch()} /></AppPage>;
  const submitInquiry = (event: FormEvent) => {
    event.preventDefault();
    if (!user) return;
    setNotice('');
    createInquiry.mutate({ id: item.id, data: { senderName: user.fullName || user.firstName || 'Student', senderPhone: senderPhone || null, message } }, {
      onSuccess: () => { setSent(true); setMessage(''); invalidate(); },
      onError: () => setNotice('Your message did not send. Please try again.'),
    });
  };
  return (
    <AppPage>
      <Link href="/" className="back-link" data-testid="link-back-market"><ArrowLeft size={16} /> Back to the shelves</Link>
      <div className="detail-layout">
        <div className="detail-visual">
          <div className="detail-main-image photo-frame">{item.imageUrls?.[0] ? <img src={item.imageUrls[0]} alt={item.title} /> : <FallbackArt category={item.category} />}</div>
          {item.imageUrls?.length > 1 && <div className="detail-thumbnails">{item.imageUrls.slice(1).map((url, i) => <img key={url} src={url} alt={`${item.title} view ${i + 2}`} />)}</div>}
          <div className="trust-note"><ShieldCheck size={18} /><span><b>Campus-to-campus</b><small>Connect directly and arrange a safe hand-off nearby.</small></span></div>
        </div>
        <div className="detail-info">
          <div className="detail-kicker"><span>{item.category}</span><span>·</span><span>{conditionLabels[item.condition]}</span><span className={`status-chip ${item.status}`}>{statusLabels[item.status]}</span></div>
          <h1>{item.title}</h1>
          <div className="detail-price">{currency(item.price)}{item.listingType === 'rent' && <span> / {item.priceUnit}</span>}</div>
          <p className="detail-description">{item.description}</p>
          <div className="detail-location"><MapPin size={16} /> {item.location}{item.availableFrom && <span>Available {new Date(item.availableFrom).toLocaleDateString()}</span>}</div>
          <div className="seller-card"><span className="seller-avatar">{item.sellerName.slice(0, 1).toUpperCase()}</span><span><small>LISTED BY</small><b>{item.sellerName}</b><small>Campus community member</small></span><ShieldCheck className="seller-check" size={19} /></div>
          <div className="detail-actions">
            <button className="button button-secondary" disabled={add.isPending || remove.isPending} onClick={() => user ? (saved ? remove : add).mutate({ id: item.id }, { onSuccess: invalidate }) : setLocation('/sign-in')} data-testid="button-detail-save"><Heart size={17} fill={saved ? 'currentColor' : 'none'} />{saved ? 'Saved' : 'Save for later'}</button>
            {item.sellerPhone && <a className="button button-primary" href={`tel:${item.sellerPhone}`} data-testid="link-seller-call"><MessageCircle size={17} /> Contact seller</a>}
          </div>
          {item.sellerEmail && <a href={`mailto:${item.sellerEmail}`} className="email-link" data-testid="link-seller-email">{item.sellerEmail}</a>}
          <form className="inquiry-form" onSubmit={submitInquiry}>
            <h3>Ask the seller a question</h3>
            {sent ? <div className="success-banner"><Check size={18} /> Message sent. You can find it in your inbox.</div> : <>
              {!user ? <div className="sign-in-prompt"><p>Sign in to message the seller and keep the conversation in your inbox.</p><Link href="/sign-in" className="button button-primary" data-testid="link-inquiry-signin">Sign in to ask <ArrowRight size={15} /></Link></div> : <>
              <textarea value={message} required minLength={5} maxLength={2000} onChange={e => setMessage(e.target.value)} placeholder="Is this still available? Could I pick it up after class?" aria-label="Your message" data-testid="input-inquiry-message" />
              <input type="tel" value={senderPhone} onChange={e => setSenderPhone(e.target.value)} placeholder="Your phone (optional)" aria-label="Your phone number" data-testid="input-inquiry-phone" />
              {notice && <p className="form-error" role="alert">{notice}</p>}
              <button className="button button-primary inquiry-submit" disabled={createInquiry.isPending} data-testid="button-send-inquiry">{createInquiry.isPending ? 'Sending…' : 'Send inquiry'}<ArrowRight size={16} /></button>
              <small className="form-help">Your inquiry goes to the seller’s campuscrate inbox.</small>
              </>}
            </>}
          </form>
        </div>
      </div>
    </AppPage>
  );
}

function SellPage() {
  const [kind, setKind] = useState<'sale' | 'rent'>('sale');
  const [uploads, setUploads] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [submitError, setSubmitError] = useState('');
  const [success, setSuccess] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const create = useCreateListing();
  const invalidate = useInvalidateMarketplace();
  const uploadFiles = async (files: FileList | null) => {
    if (!files?.length) return;
    setUploading(true); setUploadError('');
    for (const file of Array.from(files)) {
      const body = new FormData(); body.append('file', file);
      try {
        const response = await fetch('/api/uploads', { method: 'POST', body, credentials: 'include' });
        if (!response.ok) {
          const details = await response.text().catch(() => '');
          throw new Error(response.status === 503 || response.status === 500 ? 'Photo storage is not configured yet. You can still publish the listing without photos.' : `Upload failed (${response.status}). ${details}`);
        }
        const data = await response.json() as { imageUrl: string; path: string };
        if (data.imageUrl) setUploads(current => [...current, data.imageUrl]);
        else throw new Error('The upload service did not return a photo URL.');
      } catch (error) {
        setUploadError(error instanceof Error ? error.message : 'Photo upload failed. Try again, or continue without a photo.');
      }
    }
    setUploading(false);
  };
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitError('');
    const form = new FormData(event.currentTarget);
    const priceUnit = kind === 'sale' ? 'one-time' : String(form.get('priceUnit')) as ListingInput['priceUnit'];
    const data: ListingInput = {
      title: String(form.get('title')), description: String(form.get('description')),
      category: String(form.get('category')), listingType: kind,
      price: Number(form.get('price')), priceUnit,
      condition: String(form.get('condition')) as ListingInput['condition'],
      location: String(form.get('location')), sellerName: String(form.get('sellerName')),
      sellerPhone: String(form.get('sellerPhone')), sellerEmail: String(form.get('sellerEmail')) || null,
      availableFrom: kind === 'rent' ? String(form.get('availableFrom')) || null : null,
      availableUntil: kind === 'rent' ? String(form.get('availableUntil')) || null : null,
      imageUrls: uploads,
    };
    create.mutate({ data }, { onSuccess: () => { setSuccess(true); invalidate(); }, onError: () => setSubmitError('We couldn’t publish your listing. Check the details and try again.') });
  };
  return <AppPage>
    <div className="form-page-heading"><Link href="/dashboard" className="back-link" data-testid="link-back-dashboard"><ArrowLeft size={16} /> My listings</Link><span className="eyebrow">PUT IT BACK IN PLAY</span><h1>List something <em>useful.</em></h1><p>A good listing helps the right person find it. Keep it clear, keep it honest.</p></div>
    {success ? <div className="publish-success"><span className="success-seal"><Check size={26} /></span><span className="eyebrow">IT'S OUT THERE</span><h2>Your listing is live.</h2><p>Someone on campus might need exactly this.</p><div className="success-actions"><Link href="/dashboard" className="button button-primary" data-testid="link-success-dashboard">Manage listing</Link><button className="button button-secondary" onClick={() => { setSuccess(false); setUploads([]); }} data-testid="button-list-another">List another</button></div></div> :
      <form className="sell-form" onSubmit={submit}>
        <section className="form-section"><div className="form-section-heading"><span>01</span><div><h2>What are you passing on?</h2><p>Start with the basics.</p></div></div>
          <div className="listing-kind-toggle"><button type="button" onClick={() => setKind('sale')} className={kind === 'sale' ? 'chosen' : ''} data-testid="button-kind-sale"><Tag size={17} /> Sell it</button><button type="button" onClick={() => setKind('rent')} className={kind === 'rent' ? 'chosen' : ''} data-testid="button-kind-rent"><Clock3 size={17} /> Rent it out</button></div>
          <label className="field-label">Listing title<input name="title" minLength={3} maxLength={120} required placeholder="e.g. Stewart Calculus, 8th edition" data-testid="input-listing-title" /></label>
          <div className="two-fields"><label className="field-label">Category<select name="category" required defaultValue="" data-testid="select-listing-category"><option value="" disabled>Choose a category</option>{categoryOptions.map(x => <option key={x}>{x}</option>)}</select></label><label className="field-label">Condition<select name="condition" defaultValue="good" data-testid="select-listing-condition"><option value="new">New</option><option value="like-new">Like new</option><option value="good">Good</option><option value="fair">Fair</option></select></label></div>
          <label className="field-label">Description<textarea name="description" minLength={10} maxLength={3000} required placeholder="What should someone know? Add details, what’s included, and any quirks." data-testid="input-listing-description" /></label>
          <label className="field-label">Campus meet-up spot<input name="location" required placeholder="e.g. North hostel lobby" data-testid="input-listing-location" /></label>
        </section>
        <section className="form-section"><div className="form-section-heading"><span>02</span><div><h2>Price & timing</h2><p>Fair and simple is the way.</p></div></div>
          <div className="price-field-row"><label className="field-label">Price (₹)<input type="number" name="price" min="0" step="1" required placeholder="0" data-testid="input-listing-price" /></label>{kind === 'rent' && <label className="field-label">Price cadence<select name="priceUnit" defaultValue="week" data-testid="select-price-unit"><option value="day">Per day</option><option value="week">Per week</option><option value="month">Per month</option></select></label>}</div>
          {kind === 'rent' && <div className="two-fields"><label className="field-label">Available from<input type="date" name="availableFrom" data-testid="input-available-from" /></label><label className="field-label">Available until<input type="date" name="availableUntil" data-testid="input-available-until" /></label></div>}
        </section>
        <section className="form-section"><div className="form-section-heading"><span>03</span><div><h2>Show it off</h2><p>A photo makes a good find easier to spot.</p></div></div>
          <input ref={fileRef} type="file" accept="image/*" multiple className="visually-hidden" onChange={e => void uploadFiles(e.target.files)} data-testid="input-listing-photos" />
          <button type="button" className="upload-drop" onClick={() => fileRef.current?.click()} disabled={uploading} data-testid="button-upload-photos"><span className="upload-icon"><Upload size={21} /></span><b>{uploading ? 'Uploading your photos…' : 'Add photos'}</b><span>Choose image files from your device</span><small>Photos are stored securely with Supabase Storage.</small></button>
          {uploads.length > 0 && <div className="upload-previews">{uploads.map((url, i) => <div key={url}><img src={url} alt={`Listing upload ${i + 1}`} /><button type="button" onClick={() => setUploads(current => current.filter(x => x !== url))} aria-label="Remove photo" data-testid={`button-remove-photo-${i}`}><X size={14} /></button></div>)}</div>}
          {uploadError && <p className="inline-warning" role="status">{uploadError}</p>}
        </section>
        <section className="form-section"><div className="form-section-heading"><span>04</span><div><h2>How can they reach you?</h2><p>Your contact details are shown to interested students.</p></div></div>
          <div className="two-fields"><label className="field-label">Your name<input name="sellerName" required minLength={1} placeholder="Name students know you by" data-testid="input-seller-name" /></label><label className="field-label">Phone number<input type="tel" name="sellerPhone" required minLength={5} placeholder="+91 98765 43210" data-testid="input-seller-phone" /></label></div>
          <label className="field-label">Email <span className="optional-label">optional</span><input type="email" name="sellerEmail" placeholder="you@college.edu" data-testid="input-seller-email" /></label>
        </section>
        {submitError && <p className="form-error" role="alert">{submitError}</p>}
        <div className="submit-row"><span><ShieldCheck size={16} /> Only share what you’re comfortable sharing.</span><button className="button button-primary button-large" disabled={create.isPending || uploading} data-testid="button-publish-listing">{create.isPending ? 'Publishing…' : 'Publish listing'}<ArrowRight size={17} /></button></div>
      </form>}
  </AppPage>;
}

function Dashboard() {
  const { data: summary, isLoading: summaryLoading, isError: summaryError, refetch: refetchSummary } = useGetDashboardSummary();
  const { data: listings, isLoading, isError, refetch } = useGetMyListings();
  const update = useUpdateListing();
  const remove = useDeleteListing();
  const invalidate = useInvalidateMarketplace();
  const [feedback, setFeedback] = useState('');
  const changeStatus = (item: Listing, status: ListingStatus) => {
    update.mutate({ id: item.id, data: { status } }, { onSuccess: () => { setFeedback(`Marked “${item.title}” ${statusLabels[status].toLowerCase()}.`); invalidate(); }, onError: () => setFeedback('Status couldn’t be updated. Try again.') });
  };
  const deleteItem = (item: Listing) => {
    if (!window.confirm(`Remove “${item.title}” from your listings? This cannot be undone.`)) return;
    remove.mutate({ id: item.id }, { onSuccess: () => { setFeedback('Listing removed.'); invalidate(); }, onError: () => setFeedback('Could not remove listing. Try again.') });
  };
  return <AppPage><div className="dashboard-heading"><div><span className="eyebrow">YOUR LITTLE CORNER OF CAMPUS</span><h1>Good to see you <em>back.</em></h1><p>Keep track of what you’ve put into circulation.</p></div><Link href="/sell" className="button button-primary" data-testid="link-create-listing"><Plus size={17} /> List an item</Link></div>
    {summaryError ? <ErrorState retry={() => void refetchSummary()} /> : <div className="stats-row">{summaryLoading ? [0, 1, 2, 3].map(i => <div className="stat-card shimmer" key={i}></div>) : [
      { label: 'Active listings', value: summary?.activeListings ?? 0, Icon: PackageCheck },
      { label: 'Completed', value: summary?.completedListings ?? 0, Icon: Check },
      { label: 'Saved finds', value: summary?.favorites ?? 0, Icon: Heart },
      { label: 'New inquiries', value: summary?.newInquiries ?? 0, Icon: Inbox },
    ].map(({ label, value, Icon }) => <div className="stat-card" key={label}><span className="stat-icon"><Icon size={18} /></span><span className="stat-label">{label}</span><b>{value}</b></div>)}</div>}
    <div className="dashboard-listings-head"><div><span className="eyebrow">THE THINGS YOU'VE LISTED</span><h2>Your listings</h2></div><span className="count-label">{listings?.length || 0} total</span></div>
    {feedback && <div className={`feedback-banner ${feedback.includes('could') || feedback.includes('Could') ? 'feedback-error' : ''}`} role="status"><Check size={16} />{feedback}<button onClick={() => setFeedback('')} aria-label="Dismiss message"><X size={15} /></button></div>}
    {isLoading ? <ListingSkeleton /> : isError ? <ErrorState retry={() => void refetch()} /> : listings?.length ? <div className="management-list">{listings.map(item => <div className="management-row" key={item.id} data-testid={`row-my-listing-${item.id}`}><Link href={`/listing/${item.id}`} className="management-thumb">{item.imageUrls?.[0] ? <img src={item.imageUrls[0]} alt="" /> : <FallbackArt category={item.category} />}</Link><div className="management-main"><span className="card-meta">{item.category} · {item.listingType === 'rent' ? 'Rental' : 'Sale'}</span><Link href={`/listing/${item.id}`} className="management-title">{item.title}</Link><span className={`status-chip ${item.status}`}>{statusLabels[item.status]}</span></div><strong className="management-price">{currency(item.price)}{item.listingType === 'rent' ? ` / ${item.priceUnit}` : ''}</strong><label className="status-select-label"><span>Status</span><select aria-label={`Change status for ${item.title}`} value={item.status} onChange={e => changeStatus(item, e.target.value as ListingStatus)} data-testid={`select-status-${item.id}`}><option value="available">Available</option><option value="reserved">Reserved</option><option value="sold">Sold</option><option value="rented">Rented</option></select></label><button className="icon-button delete-button" onClick={() => deleteItem(item)} aria-label={`Delete ${item.title}`} disabled={remove.isPending} data-testid={`button-delete-${item.id}`}><Trash2 size={17} /></button></div>)}</div> : <EmptyState title="Your shelf is still empty." body="List a book, a cycle, or something someone else will be glad to find." action={<Link href="/sell" className="button button-primary" data-testid="link-first-listing"><Plus size={16} /> Create your first listing</Link>} />}
  </AppPage>;
}

function SavedPage() {
  const { data: favorites, isLoading, isError, refetch } = useGetFavorites();
  return <AppPage><div className="page-heading"><span className="eyebrow">A LITTLE SOMETHING FOR LATER</span><h1>Your saved <em>finds.</em></h1><p>Keep the good ones close while you decide.</p></div>{isLoading ? <ListingSkeleton /> : isError ? <ErrorState retry={() => void refetch()} /> : favorites?.length ? <div className="listing-grid">{favorites.map((item, i) => <ListingCard key={item.id} item={item} index={i} />)}</div> : <EmptyState title="Nothing tucked away yet." body="Tap the heart on anything you like. It’ll be waiting here." action={<Link href="/" className="button button-primary" data-testid="link-find-items">Explore the marketplace <ArrowRight size={16} /></Link>} />}</AppPage>;
}

function InboxPage() {
  const { user } = useUser();
  const { data: inquiries, isLoading, isError, refetch } = useGetInquiries();
  const rows = inquiries || [];
  return <AppPage><div className="page-heading"><span className="eyebrow">THE CONVERSATION STARTS HERE</span><h1>Your <em>inbox.</em></h1><p>Questions and messages about campus finds you’re passing along.</p></div>{isLoading ? <div className="inquiry-skeletons">{[0, 1, 2].map(i => <div className="inquiry-skeleton shimmer" key={i}></div>)}</div> : isError ? <ErrorState retry={() => void refetch()} /> : rows.length ? <div className="inquiry-list">{rows.map((inquiry: Inquiry) => {
    const isSent = inquiry.senderId === user?.id;
    return <article className="inquiry-card" key={inquiry.id} data-testid={`card-inquiry-${inquiry.id}`}><div className="inquiry-avatar">{inquiry.senderName.slice(0, 1).toUpperCase()}</div><div className="inquiry-copy"><div className="inquiry-topline"><b>{isSent ? `To seller · ${inquiry.listingTitle}` : inquiry.senderName}</b><time>{new Date(inquiry.createdAt).toLocaleDateString()}</time></div><span className={`inquiry-direction ${isSent ? 'sent' : 'received'}`}>{isSent ? 'Sent inquiry' : 'Received inquiry'}</span><Link href={`/listing/${inquiry.listingId}`} className="inquiry-listing">About: {inquiry.listingTitle}</Link><p>{inquiry.message}</p>{!isSent && inquiry.senderPhone && <a href={`tel:${inquiry.senderPhone}`} className="phone-chip"><MessageCircle size={14} /> Reply: {inquiry.senderPhone}</a>}</div><ArrowRight className="inquiry-arrow" size={17} /></article>;
  })}</div> : <EmptyState title="Quiet in here so far." body="When someone asks about one of your listings, their note will land here." action={<Link href="/dashboard" className="button button-secondary" data-testid="link-inbox-dashboard">See your listings <ArrowRight size={16} /></Link>} />}</AppPage>;
}

function SignInPage() {
  return <div className="auth-layout"><div className="auth-story"><Brand /><div className="auth-story-copy"><span className="eyebrow">YOUR CAMPUS, IN CIRCULATION</span><h1>Good things<br />find <em>good people.</em></h1><p>Pick up what you need. Pass along what you don’t. That’s campus life, made a little easier.</p><div className="auth-stamp"><Sparkles size={17} /> Keep useful things moving</div></div><span className="auth-footnote">A student marketplace, close to home.</span></div><div className="auth-form-side"><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /><Link href="/" className="auth-home-link" data-testid="link-auth-home"><ArrowLeft size={15} /> Back to marketplace</Link></div></div>;
}

function SignUpPage() {
  return <div className="auth-layout"><div className="auth-story"><Brand /><div className="auth-story-copy"><span className="eyebrow">MAKE ROOM FOR THE NEXT THING</span><h1>Start with<br />what's <em>already here.</em></h1><p>Join students making good finds more affordable, and campus a little less wasteful.</p><div className="auth-stamp"><ShieldCheck size={17} /> Just your campus community</div></div><span className="auth-footnote">A student marketplace, close to home.</span></div><div className="auth-form-side"><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /><Link href="/" className="auth-home-link" data-testid="link-auth-home"><ArrowLeft size={15} /> Back to marketplace</Link></div></div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);
  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) qc.clear();
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);
  return null;
}

function ListingRoute({ params }: { params: { id?: string } }) {
  return <ListingDetail id={Number(params.id)} />;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={HomeRedirect} />
    <Route path="/sign-in/*?" component={SignInPage} />
    <Route path="/sign-up/*?" component={SignUpPage} />
    <Route path="/listing/:id" component={ListingRoute} />
    <Route path="/sell">{() => <Protected><SellPage /></Protected>}</Route>
    <Route path="/dashboard">{() => <Protected><Dashboard /></Protected>}</Route>
    <Route path="/saved">{() => <Protected><SavedPage /></Protected>}</Route>
    <Route path="/inbox">{() => <Protected><InboxPage /></Protected>}</Route>
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={appearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'Welcome back to campuscrate', subtitle: 'Your next useful find is waiting.' } },
      signUp: { start: { title: 'Make yourself at home', subtitle: 'A better way to find and pass things on.' } },
    }}
    routerPush={(to) => setLocation(stripBase(to))}
    routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
  >
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ClerkQueryClientCacheInvalidator />
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  </ClerkProvider>;
}

function App() {
  if (!clerkPubKey) throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in environment.');
  return <WouterRouter base={basePath}><ClerkProviderWithRoutes /></WouterRouter>;
}

export default App;
