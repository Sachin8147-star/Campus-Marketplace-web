from django.urls import path

from marketplace import views

urlpatterns = [
    path("api/healthz", views.health_check),
    path("api/listings", views.list_listings),
    path("api/listings/<int:listing_id>", views.listing_detail),
    path("api/me/listings", views.my_listings),
    path("api/dashboard", views.dashboard_summary),
    path("api/favorites", views.favorites),
    path("api/listings/<int:listing_id>/favorite", views.favorite_detail),
    path("api/listings/<int:listing_id>/inquiries", views.listing_inquiries),
    path("api/inquiries", views.inquiries),
    path("api/uploads", views.upload_listing_photo),
]
