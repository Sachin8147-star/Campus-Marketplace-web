from rest_framework import serializers


class ListingInputSerializer(serializers.Serializer):
    title = serializers.CharField(min_length=3, max_length=120)
    description = serializers.CharField(min_length=10, max_length=3000)
    category = serializers.CharField(max_length=80)
    listingType = serializers.ChoiceField(choices=["sale", "rent"])
    price = serializers.DecimalField(max_digits=12, decimal_places=2, min_value=0)
    priceUnit = serializers.ChoiceField(choices=["one-time", "day", "week", "month"])
    condition = serializers.ChoiceField(choices=["new", "like-new", "good", "fair"])
    status = serializers.ChoiceField(
        choices=["available", "reserved", "sold", "rented"], required=False
    )
    location = serializers.CharField(max_length=160)
    sellerName = serializers.CharField(max_length=120)
    sellerPhone = serializers.CharField(min_length=5, max_length=40)
    sellerEmail = serializers.EmailField(required=False, allow_null=True, allow_blank=True)
    availableFrom = serializers.DateField(required=False, allow_null=True)
    availableUntil = serializers.DateField(required=False, allow_null=True)
    imageUrls = serializers.ListField(
        child=serializers.URLField(max_length=1200),
        required=False,
        allow_empty=True,
        max_length=8,
    )

    def validate(self, attrs):
        if (
            attrs.get("availableFrom")
            and attrs.get("availableUntil")
            and attrs["availableUntil"] < attrs["availableFrom"]
        ):
            raise serializers.ValidationError(
                {"availableUntil": "The end date must be on or after the start date."}
            )
        return attrs


class InquiryInputSerializer(serializers.Serializer):
    senderName = serializers.CharField(max_length=120)
    senderPhone = serializers.CharField(max_length=40, required=False, allow_null=True, allow_blank=True)
    message = serializers.CharField(min_length=5, max_length=2000)
