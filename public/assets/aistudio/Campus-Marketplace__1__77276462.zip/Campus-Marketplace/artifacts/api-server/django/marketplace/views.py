import json
import logging
import mimetypes
import os
from urllib.parse import quote, urlparse
from uuid import uuid4

import requests
from django.db.models import Q
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from rest_framework import serializers

from .models import Favorite, Inquiry, Listing
from .serializers import InquiryInputSerializer, ListingInputSerializer

logger = logging.getLogger(__name__)
MAX_PHOTO_BYTES = 8 * 1024 * 1024
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}


def _student_id(request: HttpRequest) -> str | None:
    value = request.headers.get("X-User-Id", "").strip()
    return value or None


def _unauthorized() -> JsonResponse:
    return JsonResponse({"error": "Sign in to continue."}, status=401)


def _json_body(request: HttpRequest) -> tuple[dict | None, JsonResponse | None]:
    try:
        body = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({"error": "Request body must be valid JSON."}, status=400)
    if not isinstance(body, dict):
        return None, JsonResponse({"error": "Request body must be an object."}, status=400)
    return body, None


def _validation_error(details) -> JsonResponse:
    return JsonResponse({"error": details}, status=400)


def _date_string(value):
    return value.isoformat() if value else None


def _listing_payload(listing: Listing) -> dict:
    return {
        "id": listing.id,
        "title": listing.title,
        "description": listing.description,
        "category": listing.category,
        "listingType": listing.listing_type,
        "price": float(listing.price),
        "priceUnit": listing.price_unit,
        "condition": listing.condition,
        "status": listing.status,
        "location": listing.location,
        "imageUrls": listing.image_urls or [],
        "sellerId": listing.seller_id,
        "sellerName": listing.seller_name,
        "sellerPhone": listing.seller_phone,
        "sellerEmail": listing.seller_email,
        "availableFrom": _date_string(listing.available_from),
        "availableUntil": _date_string(listing.available_until),
        "createdAt": listing.created_at.isoformat(),
        "updatedAt": listing.updated_at.isoformat(),
    }


def _inquiry_payload(inquiry: Inquiry) -> dict:
    return {
        "id": inquiry.id,
        "listingId": inquiry.listing_id,
        "listingTitle": inquiry.listing.title,
        "senderId": inquiry.sender_id,
        "senderName": inquiry.sender_name,
        "senderPhone": inquiry.sender_phone,
        "message": inquiry.message,
        "createdAt": inquiry.created_at.isoformat(),
    }


def _model_values(data: dict) -> dict:
    field_names = {
        "listingType": "listing_type",
        "priceUnit": "price_unit",
        "sellerName": "seller_name",
        "sellerPhone": "seller_phone",
        "sellerEmail": "seller_email",
        "availableFrom": "available_from",
        "availableUntil": "available_until",
        "imageUrls": "image_urls",
    }
    return {field_names.get(key, key): value for key, value in data.items()}


@csrf_exempt
def health_check(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    return JsonResponse({"status": "ok"})


@csrf_exempt
def list_listings(request: HttpRequest) -> JsonResponse:
    if request.method == "POST":
        student_id = _student_id(request)
        if not student_id:
            return _unauthorized()
        body, error = _json_body(request)
        if error:
            return error
        serializer = ListingInputSerializer(data=body)
        if not serializer.is_valid():
            return _validation_error(serializer.errors)
        listing = Listing.objects.create(
            seller_id=student_id,
            **_model_values(serializer.validated_data),
        )
        return JsonResponse(_listing_payload(listing), status=201)

    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)

    listings = Listing.objects.all()
    search = request.GET.get("search", "").strip()
    category = request.GET.get("category", "").strip()
    listing_type = request.GET.get("listingType", "").strip()
    condition = request.GET.get("condition", "").strip()
    status = request.GET.get("status", "").strip()

    if search:
        listings = listings.filter(
            Q(title__icontains=search)
            | Q(description__icontains=search)
            | Q(category__icontains=search)
            | Q(location__icontains=search)
        )
    if category:
        listings = listings.filter(category__iexact=category)
    if listing_type in {"sale", "rent"}:
        listings = listings.filter(listing_type=listing_type)
    if condition in {"new", "like-new", "good", "fair"}:
        listings = listings.filter(condition=condition)
    if status in {"available", "reserved", "sold", "rented"}:
        listings = listings.filter(status=status)
    else:
        listings = listings.filter(status="available")

    sort_by = request.GET.get("sortBy", "newest")
    ordering = {
        "newest": "-created_at",
        "price-low": "price",
        "price-high": "-price",
    }.get(sort_by, "-created_at")
    return JsonResponse(
        [_listing_payload(listing) for listing in listings.order_by(ordering)[:100]],
        safe=False,
    )


@csrf_exempt
def listing_detail(request: HttpRequest, listing_id: int) -> JsonResponse:
    try:
        listing = Listing.objects.get(pk=listing_id)
    except Listing.DoesNotExist:
        return JsonResponse({"error": "Listing not found."}, status=404)

    if request.method == "GET":
        return JsonResponse(_listing_payload(listing))

    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    if listing.seller_id != student_id:
        return JsonResponse({"error": "Listing not found."}, status=404)

    if request.method == "PATCH":
        body, error = _json_body(request)
        if error:
            return error
        serializer = ListingInputSerializer(data=body, partial=True)
        if not serializer.is_valid():
            return _validation_error(serializer.errors)
        if not serializer.validated_data:
            return JsonResponse({"error": "Provide at least one field to update."}, status=400)
        for field, value in _model_values(serializer.validated_data).items():
            setattr(listing, field, value)
        listing.updated_at = timezone.now()
        listing.save()
        return JsonResponse(_listing_payload(listing))

    if request.method == "DELETE":
        listing.delete()
        return HttpResponse(status=204)
    return JsonResponse({"error": "Method not allowed."}, status=405)


@csrf_exempt
def my_listings(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    listings = Listing.objects.filter(seller_id=student_id).order_by("-created_at")
    return JsonResponse([_listing_payload(listing) for listing in listings], safe=False)


@csrf_exempt
def dashboard_summary(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    own_listings = Listing.objects.filter(seller_id=student_id)
    return JsonResponse(
        {
            "activeListings": own_listings.filter(
                status__in=["available", "reserved"]
            ).count(),
            "completedListings": own_listings.filter(
                status__in=["sold", "rented"]
            ).count(),
            "favorites": Favorite.objects.filter(user_id=student_id).count(),
            "newInquiries": Inquiry.objects.filter(
                listing__seller_id=student_id
            ).exclude(sender_id=student_id).count(),
        }
    )


@csrf_exempt
def favorites(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    saved = Listing.objects.filter(favorites__user_id=student_id).order_by("-favorites__created_at")
    return JsonResponse([_listing_payload(listing) for listing in saved], safe=False)


@csrf_exempt
def favorite_detail(request: HttpRequest, listing_id: int) -> JsonResponse:
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    if request.method == "POST":
        try:
            listing = Listing.objects.get(pk=listing_id)
        except Listing.DoesNotExist:
            return JsonResponse({"error": "Listing not found."}, status=404)
        Favorite.objects.get_or_create(user_id=student_id, listing=listing)
        return HttpResponse(status=204)
    if request.method == "DELETE":
        Favorite.objects.filter(user_id=student_id, listing_id=listing_id).delete()
        return HttpResponse(status=204)
    return JsonResponse({"error": "Method not allowed."}, status=405)


@csrf_exempt
def listing_inquiries(request: HttpRequest, listing_id: int) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    try:
        listing = Listing.objects.get(pk=listing_id)
    except Listing.DoesNotExist:
        return JsonResponse({"error": "Listing not found."}, status=404)
    if listing.seller_id == student_id:
        return JsonResponse({"error": "You cannot contact yourself about your listing."}, status=400)

    body, error = _json_body(request)
    if error:
        return error
    serializer = InquiryInputSerializer(data=body)
    if not serializer.is_valid():
        return _validation_error(serializer.errors)
    inquiry = Inquiry.objects.create(
        listing=listing,
        sender_id=student_id,
        sender_name=serializer.validated_data["senderName"],
        sender_phone=serializer.validated_data.get("senderPhone") or None,
        message=serializer.validated_data["message"],
    )
    return JsonResponse(_inquiry_payload(inquiry), status=201)


@csrf_exempt
def inquiries(request: HttpRequest) -> JsonResponse:
    if request.method != "GET":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    student_id = _student_id(request)
    if not student_id:
        return _unauthorized()
    items = (
        Inquiry.objects.select_related("listing")
        .filter(Q(sender_id=student_id) | Q(listing__seller_id=student_id))
        .order_by("-created_at")[:100]
    )
    return JsonResponse([_inquiry_payload(item) for item in items], safe=False)


def _ensure_public_storage_bucket(
    supabase_url: str, bucket: str, service_role_key: str
) -> JsonResponse | None:
    headers = {
        "Authorization": f"Bearer {service_role_key}",
        "apikey": service_role_key,
    }
    bucket_url = f"{supabase_url}/storage/v1/bucket/{quote(bucket, safe='')}"
    try:
        response = requests.get(bucket_url, headers=headers, timeout=15)
        if response.status_code == 404:
            created = requests.post(
                f"{supabase_url}/storage/v1/bucket",
                headers={**headers, "Content-Type": "application/json"},
                json={
                    "id": bucket,
                    "name": bucket,
                    "public": True,
                    "file_size_limit": MAX_PHOTO_BYTES,
                    "allowed_mime_types": sorted(ALLOWED_IMAGE_TYPES),
                },
                timeout=15,
            )
            if created.ok:
                return None
            # A concurrent first upload may have created the bucket. Re-read it
            # and only continue if it is public.
            response = requests.get(bucket_url, headers=headers, timeout=15)

        if not response.ok:
            logger.warning(
                "Supabase Storage bucket check failed: status=%s",
                response.status_code,
            )
            return JsonResponse(
                {"error": "Could not verify the Supabase listing photo bucket."},
                status=502,
            )
        if not response.json().get("public", False):
            return JsonResponse(
                {
                    "error": f"The Supabase bucket '{bucket}' is private. Make it public to display listing photos."
                },
                status=502,
            )
    except (requests.RequestException, ValueError):
        logger.exception("Could not verify the Supabase listing photo bucket")
        return JsonResponse(
            {"error": "Could not verify the Supabase listing photo bucket."},
            status=502,
        )
    return None


@csrf_exempt
def upload_listing_photo(request: HttpRequest) -> JsonResponse:
    if request.method != "POST":
        return JsonResponse({"error": "Method not allowed."}, status=405)
    if not _student_id(request):
        return _unauthorized()

    photo = request.FILES.get("file")
    if not photo:
        return JsonResponse({"error": "Choose an image to upload."}, status=400)
    if photo.content_type not in ALLOWED_IMAGE_TYPES:
        return JsonResponse({"error": "Use a JPEG, PNG, or WebP image."}, status=400)
    if photo.size > MAX_PHOTO_BYTES:
        return JsonResponse({"error": "Images must be 8 MB or smaller."}, status=400)

    supabase_url = os.environ.get("SUPABASE_URL", "").rstrip("/")
    service_role_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "")
    bucket = os.environ.get("SUPABASE_STORAGE_BUCKET", "campus-listings")
    if not supabase_url or not service_role_key:
        return JsonResponse(
            {
                "error": "Photo storage is not configured yet. Add the Supabase project URL and service role key to Replit Secrets."
            },
            status=503,
        )
    if urlparse(supabase_url).scheme not in {"https", "http"} or not urlparse(supabase_url).netloc:
        return JsonResponse({"error": "Supabase URL is invalid."}, status=503)

    bucket_error = _ensure_public_storage_bucket(
        supabase_url, bucket, service_role_key
    )
    if bucket_error:
        return bucket_error

    extension = mimetypes.guess_extension(photo.content_type) or ".jpg"
    object_path = f"listing-photos/{uuid4().hex}{extension}"
    encoded_bucket = quote(bucket, safe="")
    encoded_path = quote(object_path, safe="/")
    upload_url = f"{supabase_url}/storage/v1/object/{encoded_bucket}/{encoded_path}"
    try:
        response = requests.post(
            upload_url,
            data=photo.read(),
            headers={
                "Authorization": f"Bearer {service_role_key}",
                "apikey": service_role_key,
                "Content-Type": photo.content_type,
                "x-upsert": "true",
                "cache-control": "max-age=3600",
            },
            timeout=30,
        )
    except requests.RequestException:
        logger.exception("Supabase Storage upload request failed")
        return JsonResponse({"error": "Could not reach Supabase Storage."}, status=502)

    if not response.ok:
        logger.warning("Supabase Storage rejected a listing photo upload: status=%s", response.status_code)
        return JsonResponse(
            {
                "error": f"Supabase Storage rejected the upload. Confirm that the '{bucket}' bucket exists and is public."
            },
            status=502,
        )

    image_url = (
        f"{supabase_url}/storage/v1/object/public/"
        f"{encoded_bucket}/{encoded_path}"
    )
    return JsonResponse({"imageUrl": image_url, "path": object_path}, status=201)
