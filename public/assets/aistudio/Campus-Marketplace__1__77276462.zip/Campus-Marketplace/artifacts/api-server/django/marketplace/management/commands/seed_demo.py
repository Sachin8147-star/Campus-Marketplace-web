from django.core.management.base import BaseCommand
from django.utils import timezone

from marketplace.models import Listing


class Command(BaseCommand):
    help = "Create a few clearly labelled listings for the first marketplace preview."

    def handle(self, *args, **options):
        demo_seller_id = "demo-campus-student"
        examples = [
            {
                "title": "Sample: Engineering mathematics textbook",
                "description": "A demo listing showing how a campus book offer appears. Replace this with a real item from your campus.",
                "category": "Books",
                "listing_type": "sale",
                "price": "280.00",
                "price_unit": "one-time",
                "condition": "good",
                "location": "North hostel lobby",
            },
            {
                "title": "Sample: Scientific calculator",
                "description": "A demo listing for a student calculator. Add your own photos and details when creating a real listing.",
                "category": "Calculators",
                "listing_type": "sale",
                "price": "450.00",
                "price_unit": "one-time",
                "condition": "like-new",
                "location": "Library entrance",
            },
            {
                "title": "Sample: City cycle for the semester",
                "description": "A demo rental listing. Students can set a daily, weekly, or monthly rate and add the dates it is available.",
                "category": "Cycles",
                "listing_type": "rent",
                "price": "350.00",
                "price_unit": "week",
                "condition": "good",
                "location": "East hostel cycle stand",
                "available_from": timezone.localdate(),
            },
        ]
        for item in examples:
            title = item["title"]
            Listing.objects.update_or_create(
                seller_id=demo_seller_id,
                title=title,
                defaults={
                    **item,
                    "seller_name": "Demo student",
                    "seller_phone": "",
                    "seller_email": None,
                    "image_urls": [],
                },
            )
        self.stdout.write(self.style.SUCCESS(f"Seeded {len(examples)} sample listings."))
