from django.db import models


class Listing(models.Model):
    LISTING_TYPES = [("sale", "Sale"), ("rent", "Rent")]
    PRICE_UNITS = [
        ("one-time", "One time"),
        ("day", "Per day"),
        ("week", "Per week"),
        ("month", "Per month"),
    ]
    CONDITIONS = [
        ("new", "New"),
        ("like-new", "Like new"),
        ("good", "Good"),
        ("fair", "Fair"),
    ]
    STATUSES = [
        ("available", "Available"),
        ("reserved", "Reserved"),
        ("sold", "Sold"),
        ("rented", "Rented"),
    ]

    title = models.CharField(max_length=120)
    description = models.TextField(max_length=3000)
    category = models.CharField(max_length=80, db_index=True)
    listing_type = models.CharField(max_length=8, choices=LISTING_TYPES, db_index=True)
    price = models.DecimalField(max_digits=12, decimal_places=2)
    price_unit = models.CharField(max_length=10, choices=PRICE_UNITS)
    condition = models.CharField(max_length=12, choices=CONDITIONS)
    status = models.CharField(max_length=10, choices=STATUSES, default="available", db_index=True)
    location = models.CharField(max_length=160)
    image_urls = models.JSONField(default=list, blank=True)
    seller_id = models.CharField(max_length=255, db_index=True)
    seller_name = models.CharField(max_length=120)
    seller_phone = models.CharField(max_length=40)
    seller_email = models.EmailField(null=True, blank=True)
    available_from = models.DateField(null=True, blank=True)
    available_until = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created_at"]


class Favorite(models.Model):
    user_id = models.CharField(max_length=255, db_index=True)
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="favorites")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=["user_id", "listing"], name="unique_user_listing_favorite")
        ]
        ordering = ["-created_at"]


class Inquiry(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name="inquiries")
    sender_id = models.CharField(max_length=255, db_index=True)
    sender_name = models.CharField(max_length=120)
    sender_phone = models.CharField(max_length=40, null=True, blank=True)
    message = models.TextField(max_length=2000)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
