import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import app from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const djangoDirectory = fileURLToPath(new URL("../django/", import.meta.url));
const isProduction = process.env.NODE_ENV === "production";
const djangoArgs = isProduction
  ? [
      "-m",
      "gunicorn",
      "config.wsgi:application",
      "--bind",
      "127.0.0.1:8765",
      "--workers",
      "2",
      "--timeout",
      "60",
      "--access-logfile",
      "-",
      "--error-logfile",
      "-",
    ]
  : ["manage.py", "runserver", "127.0.0.1:8765", "--noreload"];
const djangoProcess = spawn(
  process.env.PYTHON_EXECUTABLE || "python3",
  djangoArgs,
  {
    cwd: djangoDirectory,
    env: { ...process.env, PYTHONUNBUFFERED: "1" },
    stdio: "inherit",
  },
);

djangoProcess.on("error", (err) => {
  logger.error({ err }, "Could not start Django marketplace service");
  process.exit(1);
});

const stopDjango = () => {
  if (djangoProcess.exitCode === null) djangoProcess.kill("SIGTERM");
};
process.once("SIGINT", stopDjango);
process.once("SIGTERM", stopDjango);

async function waitForDjango(): Promise<void> {
  const timeoutAt = Date.now() + 30_000;
  while (Date.now() < timeoutAt) {
    if (djangoProcess.exitCode !== null) {
      throw new Error(`Django exited with code ${djangoProcess.exitCode}`);
    }
    try {
      const response = await fetch("http://127.0.0.1:8765/api/healthz", {
        signal: AbortSignal.timeout(1_000),
      });
      if (response.ok) return;
    } catch {
      // Django is still starting; retry until the startup deadline.
    }
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error("Django did not become healthy within 30 seconds.");
}

async function startServer(): Promise<void> {
  try {
    await waitForDjango();
  } catch (err) {
    logger.error({ err }, "Django marketplace service failed to start");
    stopDjango();
    process.exit(1);
  }

  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      stopDjango();
      process.exit(1);
    }

    logger.info({ port }, "API gateway listening");
  });
}

void startServer();
