import express, {
  type Express,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import { ServerResponse } from "node:http";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware, getAuth } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import { createProxyMiddleware } from "http-proxy-middleware";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// Clerk's production frontend-API proxy must run before body parsers.
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());

app.use(cors({ credentials: true, origin: true }));
app.use(
  clerkMiddleware((req) => ({
    publishableKey: publishableKeyFromHost(
      getClerkProxyHost(req) ?? "",
      process.env.CLERK_PUBLISHABLE_KEY,
    ),
  })),
);

// Preserve the API server health endpoint. The marketplace endpoints below
// are handled by the Django service, which owns the marketplace data model.
app.use("/api", router);

app.use("/api", (req: Request, res: Response, next: NextFunction) => {
  const userId = getAuth(req).userId ?? "";
  req.headers["x-user-id"] = userId;

  const isReadOnly = ["GET", "HEAD", "OPTIONS"].includes(req.method);
  if (!isReadOnly && !userId) {
    res.status(401).json({ error: "Sign in to continue." });
    return;
  }
  next();
});

// Keep uploads streaming through the gateway without parsing multipart bodies.
app.use(
  createProxyMiddleware({
    target: "http://127.0.0.1:8765",
    changeOrigin: true,
    pathFilter: (pathname) =>
      pathname === "/api" || pathname.startsWith("/api/"),
    on: {
      proxyReq(proxyReq, req) {
        const userId = req.headers["x-user-id"];
        if (typeof userId === "string" && userId) {
          proxyReq.setHeader("X-User-Id", userId);
        } else {
          proxyReq.removeHeader("X-User-Id");
        }
      },
      error(error, _req, res) {
        logger.error({ err: error }, "Django marketplace service proxy failed");
        if (res instanceof ServerResponse) {
          if (!res.headersSent) {
            res.writeHead(502, { "content-type": "application/json" });
          }
          res.end(JSON.stringify({ error: "Marketplace service is unavailable." }));
        } else {
          res.destroy(error);
        }
      },
    },
  }),
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

export default app;
