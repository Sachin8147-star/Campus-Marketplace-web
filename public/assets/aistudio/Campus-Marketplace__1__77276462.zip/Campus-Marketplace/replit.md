# CampusCrate

A student-to-student campus marketplace for discovering, selling, and renting useful college essentials.

## Run & Operate

- `pnpm --filter @workspace/campus-marketplace run dev` — run the React marketplace
- `pnpm --filter @workspace/api-server run dev` — run the Express/Clerk gateway and Django API
- `cd artifacts/api-server/django && python3 manage.py migrate` — apply Django migrations to the development PostgreSQL database
- `cd artifacts/api-server/django && python3 manage.py seed_demo` — add clearly labelled sample listings
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required environment: `DATABASE_URL`, `SESSION_SECRET`
- Supabase photo uploads: `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`; optional `SUPABASE_STORAGE_BUCKET` (defaults to `campus-listings`). A missing bucket is created as public on first upload; an existing bucket must be public.
- Clerk keys are provisioned by Replit.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9, Python 3.12
- Frontend: React + Vite
- API gateway: Express 5 with Clerk session middleware and same-origin routing
- Marketplace API: Django REST Framework
- Django runs with the development server locally and Gunicorn in production
- Database: PostgreSQL via Django ORM and psycopg
- Listing photo storage: Supabase Storage
- API contract/codegen: OpenAPI, Orval, React Query hooks
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/campus-marketplace/src/` — React app and theme
- `artifacts/api-server/src/` — Express gateway, Clerk middleware, Django process launcher
- `artifacts/api-server/django/marketplace/` — Django models, serializers, and REST views
- `lib/api-spec/openapi.yaml` — source of truth for the generated API client
- `pnpm-workspace.yaml` — workspace packages and shared React version

## Architecture decisions

- Express remains the externally routed API service so it can handle Clerk's supported web middleware; Django owns marketplace routes and database access behind a loopback proxy.
- Browser requests stay same-origin at `/api`; Clerk identity is added by the trusted gateway before Django receives writes.
- Listing photo bytes go to Supabase Storage; PostgreSQL stores the returned public image URLs with listing metadata.
- Buyers and sellers are the same student account; students can browse, save, inquire, and list items for either sale or rent.

## Product

Students can search and filter campus listings, save items, ask sellers questions, create sale or rental listings with availability dates, and manage listing status from a personal dashboard. Clerk provides student accounts. Listing photos upload to a public Supabase Storage bucket.

## User preferences

- Use React for the frontend, Django for the marketplace backend, PostgreSQL for listing data, and Supabase Storage for photos.
- Keep the interface smooth and easy to use; students must be able to list their things for rent as well as for sale.

## Gotchas

- Keep generated API hooks and Django routes aligned with `lib/api-spec/openapi.yaml`; rerun codegen after contract changes.
- The API workflow starts Django as a local child process and waits for `/api/healthz` before accepting traffic.
- Photo uploads use a public Supabase bucket; the default bucket is created on first upload if it does not exist. Without the Supabase URL and service-role key, the upload endpoint returns a clear configuration error, while non-photo listing flows remain usable.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
